"""TLC-RAPID v1.0 application entry point."""

from tlc.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
