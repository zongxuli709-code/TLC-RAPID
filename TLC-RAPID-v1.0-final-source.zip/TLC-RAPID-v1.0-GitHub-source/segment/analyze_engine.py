"""Public analysis entry point; implementation is organized in tlc/."""
from tlc.pipeline import run

__all__ = ["run"]
