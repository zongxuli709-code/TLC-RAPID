"""Trusted YOLOv5 checkpoint loading and segmentation in image coordinates."""

import os
from pathlib import Path

import numpy as np
import torch
import yaml
from app_metadata import sha256_file

from tlc.imaging import Spot, roi_rect, target_row

MODEL_SHA256 = "E507240E8C7BB8E8C3C57ABB20ADEE6FEBA78670F2EDF6E06BCF1AE12A4440A5"


class Detector:
    def __init__(
        self, weights, data, device="cpu", image_size=640, weights_sha256=MODEL_SHA256
    ):
        # The checkpoint contains Python objects. Verify the trusted digest before deserialization.
        path = Path(weights)
        if not path.is_file() or sha256_file(path) != str(weights_sha256).upper():
            raise ValueError(
                "Model SHA-256 mismatch or missing file. Use the documented model or a separately trusted digest"
            )
        os.environ.setdefault("YOLO_AUTOINSTALL", "false")
        os.environ.setdefault(
            "YOLO_CONFIG_DIR", str(path.resolve().parent.parent / "runs" / ".runtime")
        )
        from ultralytics.utils import SETTINGS

        SETTINGS.update({"sync": False})
        from models.experimental import attempt_load
        from utils.torch_utils import select_device

        self.device = select_device(device)
        self.model = attempt_load(str(path), device=self.device)
        self.stride = int(self.model.stride.max())
        self.image_size = int(np.ceil(image_size / self.stride) * self.stride)
        with open(data, encoding="utf-8") as stream:
            expected_names = yaml.safe_load(stream)["names"]
        if isinstance(expected_names, list):
            expected_names = dict(enumerate(expected_names))
        if self.model.names != expected_names:
            raise ValueError(
                "Class names in the dataset configuration do not match the model"
            )

    @torch.inference_mode()
    def predict(
        self,
        image: np.ndarray,
        confidence: float,
        iou: float,
        width: int,
        height: int,
        y_tolerance: int,
    ) -> tuple[list[Spot], list[dict]]:
        from utils.augmentations import letterbox
        from utils.general import non_max_suppression, scale_boxes
        from utils.segment.general import process_mask_native

        resized = letterbox(image, self.image_size, stride=self.stride, auto=True)[0]
        tensor = torch.from_numpy(
            np.ascontiguousarray(resized[:, :, ::-1].transpose(2, 0, 1))
        ).to(self.device)
        tensor = tensor.float().unsqueeze(0) / 255
        prediction, prototype = self.model(tensor)[:2]
        detections = non_max_suppression(
            prediction, confidence, iou, agnostic=True, max_det=100, nm=32
        )[0]
        if not len(detections):
            return [], []
        detections[:, :4] = scale_boxes(
            tensor.shape[2:], detections[:, :4], image.shape
        ).round()
        boxes = detections[:, :4].cpu().numpy().astype(int)
        selected = target_row(boxes, y_tolerance)
        spots, records = [], []
        for index, (det, box) in enumerate(zip(detections, boxes)):
            records.append(
                {
                    "box_xyxy": box.tolist(),
                    "confidence": float(det[4]),
                    "class_id": int(det[5]),
                    "selected_row": bool(selected[index]),
                }
            )
            if not selected[index]:
                continue
            rect, clipped = roi_rect(
                (box[0] + box[2]) // 2,
                (box[1] + box[3]) // 2,
                width,
                height,
                image.shape,
            )
            # Process separately to avoid allocating N full-resolution masks simultaneously.
            native = process_mask_native(
                prototype[0], det[None, 6:], det[None, :4], image.shape[:2]
            )[0]
            x1, y1, x2, y2 = rect
            mask = native[y1:y2, x1:x2].cpu().numpy().astype(bool).copy()
            spots.append(
                Spot(
                    f"auto-{index + 1}",
                    rect,
                    mask,
                    confidence=float(det[4]),
                    class_id=int(det[5]),
                    clipped=clipped,
                )
            )
        return sorted(spots, key=lambda spot: spot.rect[0] + spot.rect[2]), records
