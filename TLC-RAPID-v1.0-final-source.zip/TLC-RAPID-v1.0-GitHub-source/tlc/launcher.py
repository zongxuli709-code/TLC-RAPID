"""Small desktop launcher; all analysis runs through the same CLI in a child process."""

import os
import queue
import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from app_metadata import APP_VERSION
from app_paths import app_root

from tlc.config import (
    USER_INPUT_DIR,
    load_settings,
    update_settings_values,
    validate_user_input,
)


def open_path(path: Path) -> None:
    if sys.platform == "win32":
        os.startfile(str(path))
    else:
        subprocess.Popen(
            ["open" if sys.platform == "darwin" else "xdg-open", str(path)]
        )


class Launcher(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"TLC-RAPID v{APP_VERSION}")
        self.geometry("790x610")
        self.process = None
        self.events = queue.Queue()
        self.directory = tk.StringVar(value=str(USER_INPUT_DIR))
        self.mode = tk.StringVar(value="auto")
        self.method = tk.StringVar(value="quadratic")
        self.manual = tk.BooleanVar(value=True)
        frame = ttk.Frame(self, padding=18)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="TLC-RAPID — plate analysis", font=("Segoe UI", 18)).pack(
            anchor="w", pady=(0, 16)
        )
        row = ttk.Frame(frame)
        row.pack(fill="x")
        ttk.Entry(row, textvariable=self.directory).pack(
            side="left", fill="x", expand=True
        )
        ttk.Button(row, text="Input folder…", command=self.choose_directory).pack(
            side="left", padx=6
        )
        row = ttk.Frame(frame)
        row.pack(fill="x", pady=12)
        for label, variable, choices in (
            ("Imaging mode", self.mode, ["auto", "visible", "254nm", "366nm"]),
            ("Calibration", self.method, ["quadratic", "linear"]),
        ):
            ttk.Label(row, text=label).pack(side="left", padx=(0, 6))
            ttk.Combobox(
                row, textvariable=variable, values=choices, state="readonly", width=13
            ).pack(side="left", padx=(0, 18))
        ttk.Checkbutton(
            frame,
            text="Review every image (add, move or delete ROIs)",
            variable=self.manual,
        ).pack(anchor="w")
        ttk.Label(
            frame,
            text="Enter standard amounts in ug/band, left to right. The remaining ROIs are samples.\n"
            "Per-image imaging modes in the amount table override this mode. Auto is a color heuristic.",
            wraplength=740,
        ).pack(anchor="w", pady=12)
        controls = ttk.Frame(frame)
        controls.pack(fill="x")
        ttk.Button(
            controls, text="Open input folder", command=lambda: self.open_input()
        ).pack(side="left")
        self.start_button = ttk.Button(
            controls, text="Start analysis", command=self.start
        )
        self.start_button.pack(side="left", padx=8)
        self.results_button = ttk.Button(
            controls, text="Open results", command=self.open_results
        )
        self.results_button.pack(side="left")
        self.status = ttk.Label(
            frame,
            text="Ready. Input folder must contain settings, amount table and images.",
        )
        self.status.pack(anchor="w", pady=12)
        self.log = tk.Text(frame, wrap="word", state="disabled", height=15)
        self.log.pack(fill="both", expand=True)
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.load_options()
        self.after(100, self.poll)

    def load_options(self):
        try:
            settings = load_settings(Path(self.directory.get()))
            self.mode.set(settings["imaging_mode"])
            self.method.set(settings["quantification_method"])
        except (ValueError, OSError) as exc:
            self.status.configure(text=str(exc))

    def choose_directory(self):
        folder = filedialog.askdirectory(initialdir=self.directory.get())
        if folder:
            self.directory.set(folder)
            self.load_options()

    def open_input(self):
        directory = Path(self.directory.get())
        if directory.is_dir():
            open_path(directory)
        else:
            messagebox.showerror("Input", "Choose an existing input folder")

    def open_results(self):
        directory = app_root() / "runs" / "predict-seg"
        if directory.is_dir():
            open_path(directory)
        else:
            messagebox.showinfo("Results", "No results directory yet")

    def start(self):
        if self.process:
            return
        directory = Path(self.directory.get()).resolve()
        try:
            update_settings_values(
                {
                    "imaging_mode": self.mode.get(),
                    "quantification_method": self.method.get(),
                },
                directory,
            )
            issues = validate_user_input(directory)
            if issues:
                raise ValueError("\n".join(issue.title for issue in issues))
            command = [sys.executable]
            if not getattr(sys, "frozen", False):
                command.append(str(app_root() / "run_analysis.py"))
            command.extend(["--run", "--input-dir", str(directory)])
            if self.manual.get():
                command.append("--manual-mark")
            environment = dict(
                os.environ, PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1"
            )
            self.process = subprocess.Popen(
                command,
                cwd=app_root(),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=environment,
            )
        except (ValueError, OSError) as exc:
            messagebox.showerror("Cannot start", str(exc))
            return
        self.start_button.configure(state="disabled")
        self.status.configure(text="Running… Review each image window if enabled.")
        import threading

        threading.Thread(
            target=self.read_output, args=(self.process,), daemon=True
        ).start()

    def read_output(self, process):
        for line in process.stdout:
            self.events.put(line)
        self.events.put(process.wait())

    def poll(self):
        while not self.events.empty():
            event = self.events.get_nowait()
            if isinstance(event, int):
                self.process = None
                self.start_button.configure(state="normal")
                self.status.configure(
                    text={
                        0: "Completed. Review results before use.",
                        2: "Partially completed. Review Image_Status.",
                    }.get(
                        event, "Failed. See messages and Image_Status where available."
                    )
                )
            else:
                self.log.configure(state="normal")
                self.log.insert("end", event)
                self.log.see("end")
                self.log.configure(state="disabled")
        self.after(100, self.poll)

    def close(self):
        if self.process and self.process.poll() is None:
            messagebox.showinfo(
                "Analysis running",
                "Finish the image review and wait for analysis to complete before closing.",
            )
            return
        self.destroy()


def launch():
    Launcher().mainloop()
