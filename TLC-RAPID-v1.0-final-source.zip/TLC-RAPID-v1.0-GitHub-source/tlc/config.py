"""Strict loading of settings and explicitly supplied standard amounts."""

import math
import re
from dataclasses import dataclass
from pathlib import Path

import pandas as pd
from app_paths import app_root

from tlc.imaging import IMAGE_EXTENSIONS

ROOT = app_root()
USER_INPUT_DIR = ROOT / "user_input"
SETTINGS_NAMES = ("analysis_settings.csv", "analysis_settings.xlsx")
CONCENTRATIONS_NAMES = ("standard_concentrations.csv", "standard_concentrations.xlsx")
DEFAULT_SETTINGS = {
    "model_weights": "weights/best.pt",
    "dataset_config": "weights/boCenColor.yaml",
    "roi_width": 130,
    "roi_height": 35,
    "confidence_threshold": 0.15,
    "iou_threshold": 0.3,
    "y_tolerance": 60,
    "images_folder": "images",
    "quantification_method": "quadratic",
    "imaging_mode": "auto",
    "image_size": 640,
    "device": "cpu",
    "weights_sha256": "E507240E8C7BB8E8C3C57ABB20ADEE6FEBA78670F2EDF6E06BCF1AE12A4440A5",
}
SETTING_KEY_MAP = {
    "model_weights": "weights",
    "dataset_config": "data",
    "roi_width": "fixed_width",
    "roi_height": "fixed_height",
    "confidence_threshold": "conf_thres",
    "iou_threshold": "iou_thres",
    "images_folder": "images_subdir",
    "image_size": "imgsz",
}


@dataclass(frozen=True)
class ValidationIssue:
    level: str
    code: str
    title: str
    next_steps: tuple[str, ...]
    path: Path | None = None


def normalize_quantification_method(value) -> str:
    method = str(value).strip().lower()
    if method not in {"quadratic", "linear"}:
        raise ValueError(f"Unknown quantification_method: {value}")
    return method


def normalize_imaging_mode(value) -> str:
    mode = str(value).strip().lower()
    if mode not in {"auto", "visible", "254nm", "366nm"}:
        raise ValueError(f"Unknown imaging_mode: {value}")
    return mode


def minimum_standard_count(method) -> int:
    return 4 if normalize_quantification_method(method) == "quadratic" else 3


def _find_config_file(directory: Path, names: tuple) -> Path | None:
    found = [directory / name for name in names if (directory / name).is_file()]
    if len(found) > 1:
        raise ValueError(f"Keep only one configuration format: {', '.join(names)}")
    return found[0] if found else None


def _read_table(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".xlsx":
        return pd.read_excel(path, dtype=str, keep_default_na=False)
    return pd.read_csv(path, dtype=str, keep_default_na=False, encoding="utf-8-sig")


def validate_settings(settings: dict) -> None:
    for name in ("roi_width", "roi_height", "y_tolerance", "image_size"):
        value = float(settings[name])
        if not math.isfinite(value) or value != int(value) or not 1 <= value <= 16384:
            raise ValueError(f"{name} must be an integer between 1 and 16384")
        settings[name] = int(value)
    for name in ("confidence_threshold", "iou_threshold"):
        value = float(settings[name])
        if not math.isfinite(value) or not 0 < value <= 1:
            raise ValueError(f"{name} must be finite and in (0, 1]")
        settings[name] = value
    settings["quantification_method"] = normalize_quantification_method(
        settings["quantification_method"]
    )
    settings["imaging_mode"] = normalize_imaging_mode(settings["imaging_mode"])
    if not re.fullmatch(r"[0-9a-fA-F]{64}", str(settings["weights_sha256"])):
        raise ValueError(
            "weights_sha256 must contain the trusted 64-character SHA-256 digest"
        )


def load_settings(user_input_dir: Path | None = None) -> dict:
    directory = Path(user_input_dir or USER_INPUT_DIR)
    settings = dict(DEFAULT_SETTINGS)
    config = _find_config_file(directory, SETTINGS_NAMES)
    if config:
        table = _read_table(config)
        if not {"parameter", "value"} <= set(table.columns):
            raise ValueError("Settings table requires parameter and value columns")
        seen = set()
        for _, row in table.iterrows():
            key, value = str(row["parameter"]).strip(), str(row["value"]).strip()
            if key not in DEFAULT_SETTINGS or key in seen or not value:
                raise ValueError(f"Unknown, duplicate or empty setting: {key}")
            seen.add(key)
            settings[key] = value
    validate_settings(settings)
    values = {SETTING_KEY_MAP.get(key, key): value for key, value in settings.items()}
    values["source"] = directory / str(values["images_subdir"])
    for key in ("weights", "data"):
        path = Path(values[key])
        values[key] = path if path.is_absolute() else ROOT / path
    return values


def _amount_rows(directory: Path) -> list[tuple[str, list[float], str]]:
    config = _find_config_file(directory, CONCENTRATIONS_NAMES)
    if config is None:
        raise ValueError(
            "Missing standard_concentrations.csv; no implicit standard amounts are used"
        )
    table = _read_table(config)
    if table.empty or not {"image_filename", "amount_unit"} <= set(table.columns):
        raise ValueError(
            "Amount table requires data rows, image_filename and amount_unit"
        )
    columns = [
        col for col in table.columns if re.fullmatch(r"standard_[1-9][0-9]*", col)
    ]
    columns.sort(key=lambda col: int(col.split("_")[1]))
    if not columns or columns != [f"standard_{i + 1}" for i in range(len(columns))]:
        raise ValueError(
            "Use consecutively numbered standard_1, standard_2, ... columns"
        )
    allowed = set(columns) | {"image_filename", "amount_unit", "imaging_mode", "notes"}
    if set(table.columns) - allowed:
        raise ValueError(
            f"Unknown amount-table columns: {sorted(set(table.columns) - allowed)}"
        )
    rows, seen = [], set()
    for index, row in table.iterrows():
        name = str(row["image_filename"]).strip()
        key = (
            "_default"
            if name.lower() in {"(default)", "default", "_default"}
            else name.casefold()
        )
        if (
            not key
            or key in seen
            or (key != "_default" and ("/" in name or "\\" in name))
        ):
            raise ValueError(
                f"Row {index + 2}: missing, duplicate or invalid image filename"
            )
        seen.add(key)
        if str(row["amount_unit"]).strip() not in {"ug/band", "µg/band", "μg/band"}:
            raise ValueError(
                f"Row {index + 2}: amount_unit must be ug/band; convert solution concentration using applied volume"
            )
        cells = [str(row[col]).strip() for col in columns]
        while cells and not cells[-1]:
            cells.pop()
        try:
            amounts = [float(cell) for cell in cells]
        except ValueError as exc:
            raise ValueError(
                f"Row {index + 2}: invalid or internally missing standard amount"
            ) from exc
        if (
            not amounts
            or not all(math.isfinite(x) and x >= 0 for x in amounts)
            or len(set(amounts)) != len(amounts)
        ):
            raise ValueError(
                f"Row {index + 2}: amounts must be distinct, finite and nonnegative"
            )
        mode = str(row.get("imaging_mode", "")).strip()
        if mode:
            mode = normalize_imaging_mode(mode)
        rows.append((key, amounts, mode))
    return rows


def load_concentrations(user_input_dir: Path | None = None) -> dict[str, list[float]]:
    return {
        key: values
        for key, values, _ in _amount_rows(Path(user_input_dir or USER_INPUT_DIR))
    }


def load_image_profiles(user_input_dir: Path | None = None) -> dict[str, str]:
    return {
        key: mode
        for key, _, mode in _amount_rows(Path(user_input_dir or USER_INPUT_DIR))
        if mode
    }


def get_concentrations_for_image(
    concentrations_by_image: dict, image_name: str
) -> list[float]:
    index = {key.casefold(): values for key, values in concentrations_by_image.items()}
    if image_name.casefold() in index:
        return list(index[image_name.casefold()])
    if "_default" in index:
        return list(index["_default"])
    raise ValueError(
        f"No standard amounts configured for {image_name}; filename including extension must match"
    )


def has_explicit_concentrations(values: dict, image_name: str) -> bool:
    return image_name.casefold() in {
        key.casefold() for key in values if key != "_default"
    }


def count_images(source: Path) -> int:
    return (
        sum(
            p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS
            for p in source.iterdir()
        )
        if source.is_dir()
        else 0
    )


def update_settings_values(updates: dict, user_input_dir: Path | None = None) -> Path:
    directory = Path(user_input_dir or USER_INPUT_DIR)
    directory.mkdir(parents=True, exist_ok=True)
    path = _find_config_file(directory, SETTINGS_NAMES) or directory / SETTINGS_NAMES[0]
    table = (
        _read_table(path)
        if path.exists()
        else pd.DataFrame(DEFAULT_SETTINGS.items(), columns=["parameter", "value"])
    )
    candidate = dict(DEFAULT_SETTINGS)
    candidate.update(dict(zip(table["parameter"], table["value"])))
    if set(updates) - set(DEFAULT_SETTINGS):
        raise ValueError("Unknown settings update")
    candidate.update(updates)
    validate_settings(candidate)
    table = pd.DataFrame(candidate.items(), columns=["parameter", "value"])
    if path.suffix == ".xlsx":
        table.to_excel(path, index=False)
    else:
        table.to_csv(path, index=False, encoding="utf-8-sig")
    return path


def validate_user_input(user_input_dir: Path | None = None) -> list[ValidationIssue]:
    directory = Path(user_input_dir or USER_INPUT_DIR)
    try:
        settings = load_settings(directory)
        if not count_images(Path(settings["source"])):
            raise ValueError("Images folder is missing or contains no supported images")
        for key in ("weights", "data"):
            if not Path(settings[key]).is_file():
                raise ValueError(f"Missing {key}: {Path(settings[key]).name}")
        amounts = load_concentrations(directory)
        minimum = minimum_standard_count(settings["quantification_method"])
        for image in Path(settings["source"]).iterdir():
            if image.is_file() and image.suffix.lower() in IMAGE_EXTENSIONS:
                if len(get_concentrations_for_image(amounts, image.name)) < minimum:
                    raise ValueError(
                        f"{image.name} requires at least {minimum} standard amounts"
                    )
    except (ValueError, OSError, KeyError, TypeError) as exc:
        return [
            ValidationIssue(
                "error",
                "invalid_input",
                str(exc),
                ("Correct the input/settings and retry",),
                directory,
            )
        ]
    return []


def is_blocking_issue(issue: ValidationIssue) -> bool:
    return issue.level == "error"
