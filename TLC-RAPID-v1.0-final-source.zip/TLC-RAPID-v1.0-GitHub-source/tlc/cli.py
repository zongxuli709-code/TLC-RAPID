"""Command-line interface shared by the desktop launcher and unattended runs."""

import argparse
import logging
from pathlib import Path

from app_metadata import APP_LICENSE, APP_NAME, APP_VERSION, COPYRIGHT_NOTICE


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="TLC-RAPID quantitative still-image analysis"
    )
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--run", action="store_true", help="Run without prompts")
    mode.add_argument("--cli", action="store_true", help="Alias for --run")
    parser.add_argument(
        "--manual-mark",
        action="store_true",
        help="Open a review window for every image",
    )
    parser.add_argument(
        "--input-dir",
        type=Path,
        help="Directory containing settings, amounts and images",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        help="Parent directory for a new, unique result directory",
    )
    parser.add_argument(
        "--version", action="version", version=f"{APP_NAME} {APP_VERSION}"
    )
    parser.add_argument("--license", action="store_true")
    args = parser.parse_args(argv)
    if args.license:
        print(f"{COPYRIGHT_NOTICE}\n{APP_LICENSE}; see LICENSE. No warranty.")
        return 0
    if not (args.run or args.cli):
        if args.manual_mark or args.input_dir or args.output_dir:
            parser.error("Use --run with analysis options")
        from tlc.launcher import launch

        launch()
        return 0
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    from tlc.config import (
        load_concentrations,
        load_image_profiles,
        load_settings,
        validate_user_input,
    )

    try:
        issues = validate_user_input(args.input_dir)
        if issues:
            for issue in issues:
                print(f"Input error: {issue.title}")
            return 1
        settings = load_settings(args.input_dir)
        settings.pop("images_subdir")
        from tlc.pipeline import run

        summary = run(
            **settings,
            concentrations_by_image=load_concentrations(args.input_dir),
            image_profiles=load_image_profiles(args.input_dir),
            manual_mark=args.manual_mark,
            project=args.output_dir,
        )
        print(f"Results: {summary['excel_path']}")
        print(
            f"Success: {summary['successful_images']}; partial: {summary['partial_images']}; failed: {summary['failed_images']}"
        )
        return summary["exit_code"]
    except (ValueError, OSError, RuntimeError, KeyError) as exc:
        logging.error("Analysis stopped: %s", exc)
        return 1
