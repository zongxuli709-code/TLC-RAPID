"""TLC-RAPID quantitative still-image analysis."""
