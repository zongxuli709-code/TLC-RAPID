"""Still-image workflow: detect, optionally review, measure, calibrate and report."""

import logging
from datetime import datetime
from pathlib import Path
from uuid import uuid4

import numpy as np
from app_metadata import build_provenance, sha256_file
from app_paths import app_root

from tlc.calibration import (
    calculate_sample_concentrations,
    fit_calibration_model,
    plot_calibration_curve,
)
from tlc.config import (
    get_concentrations_for_image,
    normalize_imaging_mode,
    normalize_quantification_method,
)
from tlc.detection import MODEL_SHA256, Detector
from tlc.imaging import (
    IMAGE_EXTENSIONS,
    annotate,
    measure_spots,
    read_image,
    resolve_profile,
    write_image,
)
from tlc.reporting import write_json, write_workbook
from tlc.review import review_spots

LOGGER = logging.getLogger(__name__)


def quantify(
    records: list[dict], amounts: list[float], method: str, profile: str
) -> dict:
    if len(records) <= len(amounts):
        raise ValueError(
            f"Found {len(records)} spots; require {len(amounts)} standards plus at least one sample"
        )
    standards, samples = records[: len(amounts)], records[len(amounts) :]
    for record, amount in zip(standards, amounts):
        record.update(
            Spot_Type="standard",
            Known_Amount_Per_Band=amount,
        )
    for record in samples:
        record["Spot_Type"] = "sample"
    axis, label = ("sum_gray", "IGI") if profile == "366nm" else ("sum_od", "IOD")
    params, _ = fit_calibration_model(standards, amounts, axis, label, method)
    calculate_sample_concentrations(samples, params)
    for record in records:
        record.update(
            Calibration_R2=params["r_squared"],
            Calibration_Y_Axis=axis,
            Quantification_Method=method,
        )
        if record["Spot_Type"] == "standard":
            record["Quantification_Status"] = "standard_reference"
    return params


def run(
    *,
    weights,
    source,
    data,
    concentrations_by_image=None,
    image_profiles=None,
    quantification_method="quadratic",
    imaging_mode="auto",
    fixed_width=130,
    fixed_height=35,
    conf_thres=0.15,
    iou_thres=0.3,
    y_tolerance=60,
    imgsz=640,
    device="cpu",
    weights_sha256=MODEL_SHA256,
    manual_mark=False,
    project=None,
    detection_only=False,
):
    """Return exit 0 for success, 2 for partial success, and 1 when nothing was quantified."""
    method, mode = (
        normalize_quantification_method(quantification_method),
        normalize_imaging_mode(imaging_mode),
    )
    for value in (fixed_width, fixed_height, y_tolerance, imgsz):
        if (
            isinstance(value, bool)
            or not isinstance(value, int)
            or not 1 <= value <= 16384
        ):
            raise ValueError(
                "Image/ROI dimensions and y_tolerance must be positive integers <= 16384"
            )
    if not all(np.isfinite(v) and 0 < v <= 1 for v in (conf_thres, iou_thres)):
        raise ValueError("Confidence and IoU thresholds must be in (0, 1]")
    directory = Path(source)
    paths = sorted(
        [
            p
            for p in directory.iterdir()
            if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS
        ],
        key=lambda p: p.name.casefold(),
    )
    if not paths:
        raise ValueError("No supported still images found")
    if len({p.name.casefold() for p in paths}) != len(paths):
        raise ValueError("Input filenames must be unique ignoring case")
    if not detection_only:
        for path in paths:
            get_concentrations_for_image(concentrations_by_image or {}, path.name)
    detector = Detector(weights, data, device, imgsz, weights_sha256)
    output = (
        Path(project or app_root() / "runs" / "predict-seg")
        / f"run-{datetime.now():%Y%m%d-%H%M%S}-{uuid4().hex[:8]}"
    )
    output.mkdir(parents=True, exist_ok=False)
    settings = dict(
        conf_thres=conf_thres,
        iou_thres=iou_thres,
        fixed_width=fixed_width,
        fixed_height=fixed_height,
        y_tolerance=y_tolerance,
        imgsz=imgsz,
        device=device,
        manual_mark=manual_mark,
        imaging_mode=mode,
        quantification_method=method,
        detection_only=detection_only,
        standard_amounts=concentrations_by_image or {},
        image_profiles=image_profiles or {},
        amount_unit="ug/band",
        inference_passes=1,
        roi_selection="leftmost_detection_row",
    )
    write_json(output / "settings.json", settings)
    provenance = build_provenance(root=app_root(), weights=weights, data_config=data)
    results, statuses, manifest = [], [], []
    for index, path in enumerate(paths, 1):
        LOGGER.info("Processing %s (%s/%s)", path.name, index, len(paths))
        artifact = output / f"image-{index:04d}"
        artifact.mkdir()
        status = dict(
            Image=path.name,
            Detection_Status="failed",
            Quantification_Status="failed",
            Spot_Count=0,
            Error_Message="",
        )
        manifest.append(
            {
                "filename": path.name,
                "sha256": sha256_file(path),
                "artifact_directory": artifact.name,
            }
        )
        records, spots = [], []
        try:
            image = read_image(path)
            image.setflags(write=False)
            spots, detections = detector.predict(
                image, conf_thres, iou_thres, fixed_width, fixed_height, y_tolerance
            )
            status.update(
                Detection_Status="detected" if spots else "no_detections",
                Spot_Count=len(spots),
            )
            write_json(artifact / "detections.json", detections)
            amounts = (
                []
                if detection_only
                else get_concentrations_for_image(concentrations_by_image, path.name)
            )
            if manual_mark:
                spots, review = review_spots(
                    image, spots, fixed_width, fixed_height, len(amounts)
                )
                write_json(artifact / "review.json", review)
            status["Spot_Count"] = len(spots)
            if spots and status["Detection_Status"] == "no_detections":
                status["Detection_Status"] = "manual_only"
            write_image(
                artifact / "annotated.png", annotate(image, spots, len(amounts))
            )
            write_json(artifact / "spots.json", [s.record() for s in spots])
            # Cropped masks plus rects allow independent recalculation without the model.
            np.savez_compressed(
                artifact / "masks.npz",
                **{f"spot_{i}": s.mask for i, s in enumerate(spots)},
            )
            if detection_only:
                status["Quantification_Status"] = "not_requested"
            else:
                if not spots:
                    raise ValueError(
                        "No ROIs available; enable manual review or check image/model settings"
                    )
                profiles = image_profiles or {}
                requested_profile = profiles.get(
                    path.name.casefold(), profiles.get("_default", mode)
                )
                profile = resolve_profile(
                    normalize_imaging_mode(requested_profile), image
                )
                records = measure_spots(image, spots, profile)
                params = quantify(records, amounts, method, profile)
                write_json(artifact / "calibration.json", params)
                plot_calibration_curve(
                    records[: len(amounts)],
                    amounts,
                    params,
                    params["r_squared"],
                    artifact / "calibration.png",
                    "blue" if profile == "366nm" else "other",
                )
                sample_records = records[len(amounts) :]
                valid = sum(
                    r["Quantification_Status"] == "success" for r in sample_records
                )
                status["Quantification_Status"] = (
                    "success"
                    if valid == len(sample_records)
                    else "partial"
                    if valid
                    else "failed"
                )
                status["Valid_Samples"] = valid
                status["Rejected_Samples"] = len(sample_records) - valid
                if valid != len(sample_records):
                    status["Error_Message"] = (
                        "Some samples have no valid in-range result; see Results"
                    )
        except Exception as exc:
            status["Error_Message"] = f"{type(exc).__name__}: {exc}"
            for record in records:
                record.update(
                    Quantification_Status="failed",
                    Error_Message=status["Error_Message"],
                    Calculated_Amount_Per_Band=float("nan"),
                )
            LOGGER.error("%s: %s", path.name, status["Error_Message"])
        for record in records:
            record["Image"] = path.name
        results.extend(records)
        statuses.append(status)
        write_json(artifact / "results.json", {"status": status, "results": records})
        write_json(output / "input_manifest.json", manifest)
    successful = sum(
        s["Quantification_Status"] in {"success", "not_requested"} for s in statuses
    )
    partial = sum(s["Quantification_Status"] == "partial" for s in statuses)
    exit_code = 0 if successful == len(paths) else 2 if successful or partial else 1
    excel = output / "quantitative_analysis_all_images.xlsx"
    summary = dict(
        total_images=len(paths),
        successful_images=successful,
        partial_images=partial,
        failed_images=len(paths) - successful - partial,
        exit_code=exit_code,
        excel_path=str(excel),
    )
    provenance.update(
        Analysis_Timestamp=datetime.now().astimezone().isoformat(),
        Exit_Code=exit_code,
        Input_Manifest_SHA256=sha256_file(output / "input_manifest.json"),
        Settings_SHA256=sha256_file(output / "settings.json"),
    )
    write_json(output / "provenance.json", provenance)
    write_json(output / "summary.json", summary)
    write_workbook(excel, results, statuses, provenance)
    return summary
