"""Portable JSON and workbook reports, with explicit failure status and provenance."""

import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


def json_value(value):
    if isinstance(value, dict):
        return {str(key): json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_value(item) for item in value]
    if isinstance(value, np.generic):
        return json_value(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Path):
        return value.name
    return value


def write_json(path: Path, value) -> None:
    path.write_text(
        json.dumps(json_value(value), ensure_ascii=False, indent=2, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )


def write_workbook(path: Path, results: list, statuses: list, provenance: dict) -> None:
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        pd.DataFrame(
            [{"Field": k, "Value": str(v)} for k, v in provenance.items()]
        ).to_excel(writer, sheet_name="Metadata", index=False)
        pd.DataFrame(
            results if results else [],
            columns=None
            if results
            else ["Image", "Spot_Index", "Quantification_Status"],
        ).to_excel(writer, sheet_name="Results", index=False)
        pd.DataFrame(statuses).to_excel(writer, sheet_name="Image_Status", index=False)
        for sheet in writer.sheets.values():
            sheet.freeze_panes = "A2"
            sheet.auto_filter.ref = sheet.dimensions
            # User-controlled filenames/text must never become executable Excel formulae.
            for row in sheet:
                for cell in row:
                    if isinstance(cell.value, str):
                        cell.data_type = "s"
                    elif isinstance(cell.value, float):
                        cell.number_format = "0.0000000000"
