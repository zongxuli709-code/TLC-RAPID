"""Image geometry and measurements on unmodified, original-resolution pixels."""

from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


@dataclass
class Spot:
    """A fixed ROI with its own cropped mask; coordinates are original-image pixels."""

    identifier: str
    rect: tuple[int, int, int, int]
    mask: np.ndarray
    source: str = "auto"
    confidence: float | None = None
    class_id: int | None = None
    clipped: bool = False

    def record(self) -> dict:
        return {
            "id": self.identifier,
            "rect_xyxy": list(self.rect),
            "source": self.source,
            "confidence": self.confidence,
            "class_id": self.class_id,
            "mask_pixels": int(self.mask.sum()),
            "roi_clipped": self.clipped,
        }


def read_image(path: Path) -> np.ndarray:
    image = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_UNCHANGED)
    if image is None:
        raise ValueError(f"Cannot decode image: {path.name}")
    if image.dtype != np.uint8 or image.ndim != 3 or image.shape[2] != 3:
        raise ValueError(
            "Input must be an 8-bit, three-channel color image; convert explicitly before analysis"
        )
    return image


def write_image(path: Path, image: np.ndarray) -> None:
    ok, encoded = cv2.imencode(path.suffix, image)
    if not ok:
        raise OSError(f"Cannot encode image: {path.name}")
    encoded.tofile(path)


def roi_rect(cx: int, cy: int, width: int, height: int, shape) -> tuple:
    x, y = int(cx) - width // 2, int(cy) - height // 2
    h, w = shape[:2]
    rect = max(0, x), max(0, y), min(w, x + width), min(h, y + height)
    if rect[2] <= rect[0] or rect[3] <= rect[1]:
        raise ValueError("ROI lies outside image")
    clipped = rect != (x, y, x + width, y + height)
    return rect, clipped


def manual_spot(
    identifier: str, cx: int, cy: int, width: int, height: int, shape
) -> Spot:
    rect, clipped = roi_rect(cx, cy, width, height, shape)
    x1, y1, x2, y2 = rect
    return Spot(
        identifier,
        rect,
        np.ones((y2 - y1, x2 - x1), dtype=bool),
        "manual_rectangle",
        clipped=clipped,
    )


def target_row(boxes: np.ndarray, tolerance: int) -> np.ndarray:
    """Select the row anchored by the leftmost detection (plate layout assumption)."""
    if len(boxes) == 0:
        return np.zeros(0, dtype=bool)
    centers = (boxes[:, :2] + boxes[:, 2:4]) / 2
    anchor = centers[np.argmin(centers[:, 0]), 1]
    return np.abs(centers[:, 1] - anchor) <= tolerance


def resolve_profile(mode: str, image: np.ndarray) -> str:
    if mode != "auto":
        return mode
    h, w = image.shape[:2]
    margin = max(1, min(h, w) // 12)
    pixels = np.concatenate(
        [
            image[:margin].reshape(-1, 3),
            image[-margin:].reshape(-1, 3),
            image[:, :margin].reshape(-1, 3),
            image[:, -margin:].reshape(-1, 3),
        ]
    )
    b, g, r = pixels.mean(axis=0)
    hue, saturation, value = cv2.cvtColor(
        pixels.reshape(-1, 1, 3), cv2.COLOR_BGR2HSV
    ).mean(axis=(0, 1))
    blue = (b > r + 12 and b > g + 8 and b > 80) or (
        90 <= hue <= 135 and saturation > 35 and value > 35
    )
    return "366nm" if blue else "visible"


def lane_background(gray: np.ndarray, spots: list[Spot]) -> float:
    """Median in a shared horizontal strip, excluding every ROI plus a 10 px margin."""
    y = int(np.median([(s.rect[1] + s.rect[3]) / 2 for s in spots]))
    band = gray[max(0, y - 45) : min(gray.shape[0], y + 45)]
    keep = np.ones(band.shape, dtype=bool)
    for spot in spots:
        keep[:, max(0, spot.rect[0] - 10) : min(gray.shape[1], spot.rect[2] + 10)] = (
            False
        )
    if np.count_nonzero(keep) < 80:
        raise ValueError(
            "Insufficient unobstructed pixels for the shared lane background"
        )
    return float(np.median(band[keep]))


def measure_spots(image: np.ndarray, spots: list[Spot], profile: str) -> list[dict]:
    """Use masks for IGI/IOD; RGB/HSV/Lab are descriptive means over each fixed ROI."""
    if not spots:
        return []
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    bg = lane_background(gray, spots)
    if profile != "366nm" and bg <= 0:
        raise ValueError("Optical density requires a positive background")
    records = []
    for index, spot in enumerate(sorted(spots, key=lambda s: s.rect[0] + s.rect[2])):
        x1, y1, x2, y2 = spot.rect
        roi = gray[y1:y2, x1:x2]
        if spot.mask.shape != roi.shape or not np.any(spot.mask):
            raise ValueError(
                f"Spot {spot.identifier} has an empty or incompatible segmentation mask"
            )
        pixels = roi[spot.mask].astype(np.float64)
        fluorescence = profile == "366nm"
        net = np.maximum(pixels - bg if fluorescence else bg - pixels, 0)
        # Intensity floor of 1 DN; saturated pixels are reported explicitly below.
        od = np.maximum(np.log10(max(bg, 1) / np.maximum(pixels, 1)), 0)
        color = image[y1:y2, x1:x2]
        b, g, r = color.mean(axis=(0, 1))
        h, s, v = cv2.cvtColor(color, cv2.COLOR_BGR2HSV).mean(axis=(0, 1))
        lab = cv2.cvtColor(color.astype(np.float32) / 255.0, cv2.COLOR_BGR2Lab)
        lightness, a, b_lab = lab.mean(axis=(0, 1))
        chroma = np.hypot(lab[:, :, 1], lab[:, :, 2]).mean()
        records.append(
            {
                "Spot_Index": index,
                "Spot_ID": spot.identifier,
                "Spot_Source": spot.source,
                "X_Position": (x1 + x2) // 2,
                "Y_Position": (y1 + y2) // 2,
                "ROI_X1": x1,
                "ROI_Y1": y1,
                "ROI_X2": x2,
                "ROI_Y2": y2,
                "Width": x2 - x1,
                "Height": y2 - y1,
                "ROI_Clipped": spot.clipped,
                "Mask_Pixels": len(pixels),
                "Confidence": spot.confidence,
                "Class_ID": spot.class_id,
                "Lane_Background": bg,
                "Signal_Polarity": "fluorescence" if fluorescence else "absorption",
                "Mean_Gray": float(pixels.mean()),
                "Sum_Gray": float(pixels.sum()),
                "Sum_Gray_Corrected": float(net.sum()),
                "Net_Signal": float(net.sum()),
                "IGI": float(net.sum()),
                "Sum_OD": float(od.sum()),
                "IOD": float(od.sum()),
                "Saturated_Mask_Pixels": int(
                    np.count_nonzero((pixels == 0) | (pixels == 255))
                ),
                "OD_Method": "lane_shared+mask; intensity_floor=1DN",
                "R": float(r),
                "G": float(g),
                "B": float(b),
                "H": float(h),
                "S": float(s),
                "V": float(v),
                "L": float(lightness),
                "A": float(a),
                "B_lab": float(b_lab),
                "C": float(chroma),
                "Imaging_Mode": profile,
                "Amount_Unit": "ug/band",
            }
        )
    return records


def annotate(
    image: np.ndarray, spots: list[Spot], standard_count: int = 0
) -> np.ndarray:
    canvas = image.copy()
    for index, spot in enumerate(sorted(spots, key=lambda s: s.rect[0] + s.rect[2])):
        x1, y1, x2, y2 = spot.rect
        color = (0, 200, 0) if index < standard_count else (0, 190, 255)
        prefix = "S" if index < standard_count else "U"
        cv2.rectangle(canvas, (x1, y1), (x2 - 1, y2 - 1), color, 2)
        cv2.putText(
            canvas,
            f"{prefix}{index + 1}",
            (x1, max(18, y1 - 5)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            color,
            2,
        )
    return canvas
