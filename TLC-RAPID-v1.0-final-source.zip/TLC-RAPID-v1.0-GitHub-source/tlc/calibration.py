"""Calibration fitting, bounded inversion and presentation."""

import matplotlib
import numpy as np
from scipy import stats
from sklearn.metrics import r2_score

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from tlc.calibration_safety import inspect_quadratic_domain

CALIBRATION_R2_WARNING_THRESHOLD = 0.75


def _extract_y_value(result: dict, y_axis_type: str) -> float:
    key = {"sum_gray": "Sum_Gray_Corrected", "sum_od": "Sum_OD"}.get(y_axis_type)
    if key is None:
        raise ValueError(f"Unsupported response axis: {y_axis_type}")
    return float(result[key])


def _fit_polynomial(
    concentrations: np.ndarray, responses: np.ndarray, method: str
) -> tuple[list[float], float]:
    """Return unified [a, b, c] coefficients and R2 for quadratic or linear regression."""
    fitted = np.polyfit(
        concentrations, responses, deg=2 if method == "quadratic" else 1
    )
    if method == "quadratic":
        a, b, c = (float(value) for value in fitted)
    else:
        b, c = (float(value) for value in fitted)
        a = 0.0
        if abs(b) < 1e-12:
            raise ValueError(
                "Linear calibration failed because the fitted slope is zero"
            )
    coefs = [a, b, c]
    predicted = np.polyval(coefs, concentrations)
    r_squared = (
        float(r2_score(responses, predicted)) if len(np.unique(responses)) > 1 else 0.0
    )
    return coefs, r_squared


def fit_calibration_model(
    standard_results,
    standard_concentrations,
    y_axis_type="sum_od",
    y_label=None,
    quantification_method="quadratic",
):
    """Fit an identifiable calibration; never silently change the requested model."""
    from tlc.calibration_safety import require_unambiguous_quadratic

    method = str(quantification_method).lower()
    if method not in ("linear", "quadratic"):
        raise ValueError(f"Unsupported calibration method: {method}")
    x = np.asarray(standard_concentrations, dtype=float)
    y = np.asarray(
        [_extract_y_value(r, y_axis_type) for r in standard_results], dtype=float
    )
    minimum = 4 if method == "quadratic" else 3
    if x.ndim != 1 or len(x) != len(y) or len(x) < minimum:
        raise ValueError(f"{method} requires at least {minimum} matched standards")
    if not np.isfinite(x).all() or not np.isfinite(y).all() or (x < 0).any():
        raise ValueError(
            "Standards and responses must be finite; amounts must be nonnegative"
        )
    if len(np.unique(x)) != len(x) or np.ptp(y) <= 1e-12:
        raise ValueError("Standard amounts must be distinct and responses must vary")
    if any(r.get("ROI_Clipped", False) for r in standard_results):
        raise ValueError(
            "A standard ROI crosses the image boundary; reacquire or correct the ROI"
        )
    coefs, r2 = _fit_polynomial(x, y, method)
    a, b, c = coefs
    domain = inspect_quadratic_domain(a, b, float(x.min()), float(x.max()))
    if method == "quadratic":
        require_unambiguous_quadratic(domain)
    # Integrated absorption/fluorescence response must increase with applied amount.
    if (
        min(2 * a * x.min() + b, 2 * a * x.max() + b) < -1e-12
        or max(abs(2 * a * x.min() + b), abs(2 * a * x.max() + b)) <= 1e-12
    ):
        raise ValueError(
            "Calibration response does not increase with amount; verify standard order and signal"
        )
    if not np.isfinite(r2) or r2 < CALIBRATION_R2_WARNING_THRESHOLD:
        raise ValueError(
            f"Calibration R2={r2:g} is below the software guard ({CALIBRATION_R2_WARNING_THRESHOLD}); review the standards"
        )
    params = dict(
        fit_type=method,
        quantification_method=method,
        method_selection=method,
        requested_method=method,
        coefs=coefs,
        a=a,
        b=b,
        c=c,
        r_squared=float(r2),
        calibration_quality="passed_software_guards",
        y_axis_type=y_axis_type,
        y_label=y_label or y_axis_type,
        x_label="Applied amount (ug/band)",
        quantity_unit="ug/band",
        X_original=x.tolist(),
        y_original=y.tolist(),
        conc_min=float(x.min()),
        conc_max=float(x.max()),
        y_min=float(y.min()),
        y_max=float(y.max()),
        spearman=float(stats.spearmanr(x, y).statistic),
        order_reversed=False,
        quadratic_vertex=domain.vertex,
        quadratic_vertex_in_range=domain.vertex_in_range,
    )
    return params, float(r2)


def _range_tolerance(base: float, rel: float = 1e-9, abs_tol: float = 1e-9) -> float:
    return max(abs_tol, abs(float(base)) * rel)


def assess_sample_quantification_range(y_value, amount, calibration_params):
    """Check both the measured response range and the standard amount interval."""
    lo, hi = calibration_params["conc_min"], calibration_params["conc_max"]
    ylo, yhi = calibration_params["y_min"], calibration_params["y_max"]
    amount_ok = np.isfinite(amount) and lo - _range_tolerance(
        lo
    ) <= amount <= hi + _range_tolerance(hi)
    response_ok = np.isfinite(y_value) and ylo - _range_tolerance(
        ylo
    ) <= y_value <= yhi + _range_tolerance(yhi)
    reasons = []
    if not np.isfinite(amount):
        reasons.append("no_unique_in_range_solution")
    elif not amount_ok:
        reasons.append("amount_outside_standards")
    if not response_ok:
        reasons.append("response_outside_standards")
    return {
        "Out_of_Range": bool(reasons),
        "Range_Status": ";".join(reasons) or "in_range",
        "Response_In_Range": bool(response_ok),
        "Amount_In_Range": bool(amount_ok),
        "Calibration_Response_Min": ylo,
        "Calibration_Response_Max": yhi,
        "Calibration_Amount_Min": lo,
        "Calibration_Amount_Max": hi,
    }


def select_quadratic_root(y_value, calibration_params):
    """Return only a unique root inside the calibration interval."""
    a, b, c = (float(calibration_params[k]) for k in ("a", "b", "c"))
    lo, hi = (float(calibration_params[k]) for k in ("conc_min", "conc_max"))
    result = dict(
        roots=[],
        in_range_roots=[],
        selected=None,
        reason="no_root_in_working_range",
    )
    if not all(np.isfinite(v) for v in (y_value, a, b, c, lo, hi)):
        result["reason"] = "nonfinite_input"
        return result
    if inspect_quadratic_domain(a, b, lo, hi).vertex_in_range:
        result["reason"] = "nonmonotonic_calibration"
        return result
    if a == 0:
        roots = [] if abs(b) < 1e-12 else [(y_value - c) / b]
    else:
        roots = [
            float(r.real) for r in np.roots([a, b, c - y_value]) if abs(r.imag) < 1e-9
        ]
    result["roots"] = roots
    tol = max(1.0, abs(lo), abs(hi)) * 1e-9
    valid = []
    for r in roots:
        if lo - tol <= r <= hi + tol and not any(abs(r - v) <= tol for v in valid):
            valid.append(min(hi, max(lo, r)))
    result["in_range_roots"] = valid
    if len(valid) == 1:
        result.update(selected=valid[0], reason="unique_root_in_working_range")
    elif len(valid) > 1:
        result["reason"] = "ambiguous_roots"
    return result


def solve_concentration_from_linear(y_value: float, calibration_params: dict) -> float:
    """Back-calculate concentration from y = bx + c."""
    slope = float(calibration_params["b"])
    intercept = float(calibration_params["c"])
    if abs(slope) < 1e-12:
        raise ValueError(
            "Linear calibration cannot be inverted because its slope is zero"
        )
    return float((y_value - intercept) / slope)


def calculate_sample_concentrations(sample_results, calibration_params):
    """Quantify in-range samples only; NaN is exported as a blank numeric cell."""
    method = calibration_params["quantification_method"]
    for result in sample_results:
        y = _extract_y_value(result, calibration_params["y_axis_type"])
        details = (
            select_quadratic_root(y, calibration_params)
            if method == "quadratic"
            else None
        )
        value = (
            details["selected"]
            if details
            else solve_concentration_from_linear(y, calibration_params)
        )
        value = float(value) if value is not None else float("nan")
        info = assess_sample_quantification_range(y, value, calibration_params)
        if result.get("ROI_Clipped", False):
            info.update(Out_of_Range=True, Range_Status="roi_clipped")
        if not np.isfinite(y):
            info.update(Out_of_Range=True, Range_Status="nonfinite_response")
        if info["Out_of_Range"]:
            value = float("nan")
        result.update(info)
        result.update(
            Calculated_Amount_Per_Band=value,
            Amount_Unit="ug/band",
            Applied_Method=method,
            Quantification_Status="rejected" if info["Out_of_Range"] else "success",
        )
        if details:
            result.update(
                Selected_Root=details["selected"],
                Root_Selection_Reason=details["reason"],
            )
    return sample_results


def plot_calibration_curve(
    standard_results,
    standard_concentrations,
    calibration_params,
    r_squared,
    save_path,
    background_type="other",
):
    """Plot measured standards and the selected calibration model."""
    plt.rcParams["font.sans-serif"] = [
        "DejaVu Sans",
        "Arial",
        "Helvetica",
        "sans-serif",
    ]
    plt.rcParams["axes.unicode_minus"] = False

    y_axis_type = calibration_params["y_axis_type"]
    y_label = calibration_params["y_label"]
    concentrations = np.asarray(standard_concentrations, dtype=float)
    y_values = np.asarray(
        [_extract_y_value(r, y_axis_type) for r in standard_results], dtype=float
    )
    bg_name = "Blue background" if background_type == "blue" else "Other background"
    spearman = calibration_params.get("spearman", None)
    quant_mode = str(
        calibration_params.get("quantification_method", "quadratic")
    ).lower()

    order = np.argsort(concentrations)
    x_sorted = concentrations[order]
    y_sorted = y_values[order]
    plt.figure(figsize=(12, 8))
    plt.scatter(
        x_sorted, y_sorted, color="blue", s=70, label="Standards (measured)", zorder=5
    )
    for x, y in zip(x_sorted, y_sorted):
        plt.annotate(
            f"{x:.5f}",
            (x, y),
            textcoords="offset points",
            xytext=(5, 5),
            ha="left",
            fontsize=8,
            alpha=0.7,
        )

    x_min, x_max = float(x_sorted.min()), float(x_sorted.max())
    x_fit = np.linspace(x_min, x_max, 200)
    y_fit = np.polyval(calibration_params["coefs"], x_fit)
    fit_r2 = float(calibration_params.get("r_squared", r_squared))
    model_label = "Quadratic" if quant_mode == "quadratic" else "Linear"
    plt.plot(
        x_fit,
        y_fit,
        "r-",
        linewidth=2.5,
        label=f"{model_label} calibration (R2={fit_r2:.3f})",
    )

    plt.xlabel("Applied amount (ug/band)", fontsize=12)
    plt.ylabel(y_label, fontsize=12)
    title = f"TLC calibration curve ({bg_name})\nApplied amount vs {y_label}"
    if spearman is not None:
        title += f"\nMeasured Spearman={float(spearman):.3f} (red = {quant_mode} quantification)"
    plt.title(title, fontsize=13)
    plt.legend(fontsize=9, loc="best")
    plt.grid(True, alpha=0.3)

    a, b, c = calibration_params["a"], calibration_params["b"], calibration_params["c"]
    if quant_mode == "quadratic":
        equation = f"y={a:.4g}x^2{b:+.4g}x{c:+.4g}"
    else:
        equation = f"y={b:.4g}x{c:+.4g}"
    info = f"{model_label}: {equation} (R2={fit_r2:.4f})\nMethod: {quant_mode} regression back-calculation"
    plt.text(
        0.98,
        0.02,
        info,
        transform=plt.gca().transAxes,
        fontsize=10,
        verticalalignment="bottom",
        horizontalalignment="right",
        bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.85),
    )

    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close()
