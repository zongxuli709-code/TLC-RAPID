"""Optional review of all ROIs, including automatic detections and empty images."""

import cv2

from tlc.imaging import Spot, annotate, manual_spot


class ReviewState:
    """UI-independent edit state; unchanged automatic ROIs retain their original masks."""

    def __init__(self, spots: list[Spot], shape, width: int, height: int):
        self.original = list(spots)
        self.spots = list(spots)
        self.shape, self.width, self.height = shape, width, height
        self.next_id = 1

    def hit(self, x: int, y: int) -> int | None:
        for index in range(len(self.spots) - 1, -1, -1):
            x1, y1, x2, y2 = self.spots[index].rect
            if x1 <= x < x2 and y1 <= y < y2:
                return index
        return None

    def add(self, x: int, y: int) -> int:
        if self.hit(x, y) is not None:
            raise ValueError("A spot already occupies this position")
        self.spots.append(
            manual_spot(
                f"manual-{self.next_id}", x, y, self.width, self.height, self.shape
            )
        )
        self.next_id += 1
        return len(self.spots) - 1

    def move(self, index: int, x: int, y: int) -> None:
        old = self.spots[index]
        center = ((old.rect[0] + old.rect[2]) // 2, (old.rect[1] + old.rect[3]) // 2)
        if center != (x, y):
            self.spots[index] = manual_spot(
                old.identifier, x, y, self.width, self.height, self.shape
            )


def review_spots(
    image, spots: list[Spot], width: int, height: int, standard_count: int = 0
) -> tuple[list[Spot], dict]:
    state = ReviewState(spots, image.shape, width, height)
    scale = min(1.0, 1400 / image.shape[1], 850 / image.shape[0])
    title = "Review ROIs | Drag: move | Right: delete | S: accept | Esc: cancel edits"
    selected, dragging, origin, offset = None, False, None, (0, 0)

    def mouse(event, x, y, flags, parameter):
        nonlocal selected, dragging, origin, offset
        x, y = int(x / scale), int(y / scale)
        x, y = min(x, image.shape[1] - 1), min(y, image.shape[0] - 1)
        hit = state.hit(x, y)
        if event == cv2.EVENT_LBUTTONDOWN:
            selected = hit if hit is not None else state.add(x, y)
            rect = state.spots[selected].rect
            offset = (rect[0] + rect[2]) // 2 - x, (rect[1] + rect[3]) // 2 - y
            origin, dragging = (x, y), True
        elif event == cv2.EVENT_MOUSEMOVE and dragging and (x, y) != origin:
            state.move(selected, x + offset[0], y + offset[1])
        elif event == cv2.EVENT_LBUTTONUP:
            dragging = False
        elif event == cv2.EVENT_RBUTTONDOWN and hit is not None:
            state.spots.pop(hit)
            selected, dragging = None, False

    accepted = False
    cv2.namedWindow(title, cv2.WINDOW_AUTOSIZE)
    try:
        cv2.setMouseCallback(title, mouse)
        while True:
            canvas = annotate(image, state.spots, standard_count)
            cv2.imshow(title, cv2.resize(canvas, None, fx=scale, fy=scale))
            key = cv2.waitKey(20) & 0xFF
            if key in (ord("s"), ord("S")):
                accepted = True
                break
            if key == 27 or cv2.getWindowProperty(title, cv2.WND_PROP_VISIBLE) < 1:
                break
    finally:
        cv2.destroyWindow(title)
    final = state.spots if accepted else state.original
    return final, {
        "accepted": accepted,
        "before": [s.record() for s in state.original],
        "after": [s.record() for s in final],
    }
