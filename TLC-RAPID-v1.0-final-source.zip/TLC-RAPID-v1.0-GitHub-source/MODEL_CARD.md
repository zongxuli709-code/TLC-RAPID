# TLC-RAPID model card

The bundled model performs TLC spot instance segmentation using the YOLOv5s-seg architecture family with 27 classes. The checkpoint records a 640-pixel training input and a 2025-04-29 timestamp. It is intended for research images of TLC plates acquired under visible light, 254 nm and 366 nm conditions.

The checkpoint records 1,000 requested epochs, early-stopping patience 100, batch size 16, SGD and seed 0. It is stripped for inference: the stored epoch is -1 and final validation metrics and an exact upstream source commit are not recorded. Training/validation manifests, plate grouping, annotation agreement and final model-selection evidence are not included. The supplied examples cannot establish performance.

Performance depends on illumination, camera, plate type, image size, orientation and sample morphology. Review detections and the assumed standard/sample order. Manual ROI changes are recorded. A numerically valid calibration is not sufficient evidence of analytical validity.

The loader verifies the documented model SHA-256 before deserializing its Python objects. Only use a different checkpoint when its source and hash are independently trusted; updating a checksum alone does not make an unknown checkpoint safe. Model and source hashes are recorded with every run. See `MODEL_WEIGHTS.md`.
