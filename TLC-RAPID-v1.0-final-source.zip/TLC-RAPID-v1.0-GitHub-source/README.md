# TLC-RAPID v1.0

TLC-RAPID segments TLC bands and estimates applied sample amounts from standards on the same plate. It supports 8-bit color still images acquired under visible light, 254 nm, or 366 nm. [中文说明](README_zh.md).

## Installation

The reference environment is Windows x64 with Python 3.12. The source, the inference model and five workflow images are included. No executable or Python interpreter is included.

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run_analysis.py
```

An activated virtual environment can also use `python run_analysis.py` or `run_analysis.bat`. The runtime dependency versions are fixed in `requirements-lock.txt`. CPU inference is the default. Other platforms, Python versions and GPU installations require their own validation.

## Analyze your images

1. Put images in `user_input/images/`. Accepted extensions: JPG, JPEG, PNG, BMP, TIF, TIFF and WEBP. Convert grayscale, alpha-channel or 16-bit images explicitly to 8-bit BGR/RGB color before analysis. Keep the image orientation, resolution and acquisition conditions consistent.
2. Fill `user_input/standard_concentrations.csv`. Despite this conventional filename, the input quantity is **applied amount in ug/band**, not solution concentration. There are no built-in standard amounts.
3. Check `user_input/analysis_settings.csv`, then start the launcher or run the command below.

```powershell
.\.venv\Scripts\python.exe run_analysis.py --run
```

`--run` does not prompt or open image windows. Add `--manual-mark` to review every image. `--input-dir PATH` selects a complete input folder; `--output-dir PATH` selects a parent for newly created result folders. `--help`, `--version` and `--license` are also available.

An amount-table row looks like:

```csv
image_filename,standard_1,standard_2,standard_3,standard_4,standard_5,amount_unit,imaging_mode,notes
plate.png,0.5,1,2,3,4,ug/band,visible,Standards ordered left to right
```

Use the exact filename including extension; matching ignores case. A `(default)` row is used only when you explicitly supply it. Standard columns are ordered by their numerical suffix. Internal missing values, duplicate amounts, invalid numbers, unknown columns, unknown settings and duplicate CSV/XLSX configurations are rejected. Trailing unused standard cells may be empty. Each image requires at least four standards for a quadratic fit or three for a linear fit, followed by at least one sample.

For a standard solution, `amount (ug/band) = concentration (mg/mL) × application volume (uL)`. The calculated amount is not automatically converted to solution concentration or herbal content. Those conversions require sample volumes, dilution factors and preparation records.

## Detection and review

The default detector uses confidence 0.15, class-agnostic NMS IoU 0.30 and a 640-pixel model input. Original-resolution masks are cropped to fixed 130 × 35-pixel ROIs. The target row is anchored by the leftmost detection, with a vertical tolerance of 60 pixels. The first N accepted ROIs from left to right are standards; the remaining ROIs are samples. This is a plate-layout assumption, not chemical identification. Check missing detections and ordering before interpreting results.

The analysis uses one inference pass. It does not choose thresholds, responses, calibration models or quadratic branches from sample results. Settings `roi_width`, `roi_height`, `confidence_threshold`, `iou_threshold`, `y_tolerance`, `image_size`, `device`, `model_weights`, `weights_sha256`, `dataset_config`, `images_folder`, `imaging_mode` and `quantification_method` are documented by their names in the supplied settings table.

In the review window, left-click empty space to add a ROI, drag a ROI to move it, and right-click a ROI to delete it. Press **S** to accept or **Esc** to discard edits. Closing the window also discards edits. Automatic ROIs can be edited, including on images with no automatic detections. Unchanged automatic ROIs retain their segmentation masks; added or moved ROIs use the full rectangle and are identified as `manual_rectangle`. A review record preserves the original and accepted geometry. Manual and automatic integration regions differ and must be reported in quantitative work.

## Measurement and calibration

All measurements use the decoded original pixels. Drawing never modifies the measurement image. A shared lane background is the median of a horizontal ±45-pixel strip, excluding every ROI plus a 10-pixel horizontal margin; fewer than 80 remaining background pixels cause rejection.

- **366 nm:** IGI is the sum of `max(I − background, 0)` over the mask.
- **Visible / 254 nm:** IOD is the sum of `max(log10(background / max(I, 1)), 0)` over the mask. The intensity floor is 1 digital number. `IOD` and `Sum_OD` contain the same value.
- RGB/HSV/Lab/chroma columns are descriptive averages over the full fixed ROI, not calibration responses. Lab uses floating-point CIELAB coordinates. Saturated mask pixels and clipped ROIs are reported.

RGB and S/V use 0–255 encoding; H uses OpenCV's 0–179 encoding. L is CIELAB lightness (0–100), A/B_lab are signed CIELAB coordinates, and C is the mean pixel chroma. Mean_Gray and the signal integrals use mask pixels. `Sum_Gray` is the uncorrected masked gray sum; `IGI` is background-corrected.

Select the acquired imaging mode explicitly. `auto` is a border-color heuristic that distinguishes blue fluorescence from other images; it cannot determine the acquisition wavelength. An optional per-image `imaging_mode` column overrides the global setting.

Calibration is an unweighted least-squares linear or quadratic fit. The software rejects nonfinite or duplicate standard amounts, degenerate responses, clipped standard ROIs, a decreasing fitted response, a quadratic vertex inside the standard interval, and R² below 0.75. This R² threshold is a software guard, **not an analytical validation criterion**. Detector accuracy, saturation, background suitability, residuals, recovery and measurement uncertainty still require experimental assessment.

Only a unique inverse within the standard amount interval and observed standard response range is reported. Out-of-range or ambiguous results remain blank/null with a reason; there is no extrapolation, endpoint clipping, interpolation fallback or automatic model switching. Select a different model only when justified by your analytical procedure.

## Output

Every run creates a new directory under `runs/predict-seg/`:

- `quantitative_analysis_all_images.xlsx`: `Metadata`, `Results` and `Image_Status` sheets. Read `Calculated_Amount_Per_Band` with `Amount_Unit` and `Quantification_Status`.
- `settings.json`, `input_manifest.json`, `provenance.json`: settings, input SHA-256 values, model/config/source hashes and environment versions.
- `image-0001/`, etc.: original-image ROI annotations, detection records, accepted ROI geometry, cropped masks (`masks.npz`), measurements and status; successful calibrations also include full-precision coefficients and a curve plot. A masks.npz entry `spot_i` corresponds to entry i in `spots.json`.

Exit status is 0 for complete success, 2 for partial success, and 1 when no image produces a valid quantitative sample result or setup fails. Individual rejected samples are never represented as a successful complete image. Corrupt images are recorded and the remaining images continue. JSON represents unavailable numbers as null; Excel leaves them blank.

## Examples

```powershell
.\.venv\Scripts\python.exe run_analysis.py --run --input-dir example_data
```

The five images exercise the workflow; they are not a benchmark or a promise of successful automatic quantification. Some require ROI correction or a scientifically justified calibration procedure and may be rejected by the supplied defaults. See [example_data/README.md](example_data/README.md).

## Source layout

`run_analysis.py` is the application entry point. `tlc/cli.py` and `tlc/launcher.py` provide interfaces; `tlc/config.py` validates inputs; `tlc/detection.py` loads the trusted model and creates image-coordinate masks; `tlc/imaging.py` handles geometry and measurements; `tlc/review.py` handles ROI editing; `tlc/calibration.py` handles fitting/inversion; `tlc/pipeline.py` coordinates the workflow; `tlc/reporting.py` writes results. `app_metadata.py` records provenance.

`models/`, most of `utils/`, and `export.py` retain YOLOv5-derived support code. Their module paths are required by the serialized model. `segment/analyze_engine.py` exposes the analysis function.

## License and citation

TLC-RAPID and the supplied model are distributed under AGPL-3.0-only. Preserve [LICENSE](LICENSE), [COPYRIGHT.txt](COPYRIGHT.txt) and [THIRD_PARTY_NOTICES.txt](THIRD_PARTY_NOTICES.txt). Model scope and provenance are in [MODEL_CARD.md](MODEL_CARD.md) and [MODEL_WEIGHTS.md](MODEL_WEIGHTS.md). Cite the software using `CITATION.cff`. The workflow examples have their own accompanying data notice.
