# Workflow examples

Five author-supplied TLC images are bundled. The CSV uses applied standard amounts, converted from the standard solution concentrations and application volumes supplied with the experimental records.

| Image | Mode | Standard application volume (uL) | Amounts (ug/band), left to right |
|---|---|---:|---|
| Arnebiae Radix.jpg | visible | 22 | 0.6875, 1.375, 2.75, 5.5, 11 |
| Lonicerae Japonicae Flos.jpg | 366nm | 3 | 0.375, 0.6, 0.75, 1.5, 3 |
| Lonicerae Flos.jpg | 366nm | 2 | 0.125, 0.25, 0.5, 1, 2 |
| Gentianae Macrophyllae Radix.jpg | 254nm | 8 | 1, 2, 4, 6, 8 |
| Phellodendri Chinensis Cortex.jpg | visible | 3 | 1.5, 2.25, 3, 4.5, 6 |

Run from the application root: `python run_analysis.py --run --input-dir example_data`. Add `--manual-mark` to review ROIs. The supplied settings request quadratic calibration. Missing detections, out-of-range responses and non-monotonic fits can produce rejected results. These images demonstrate handling and review, not guaranteed successful automatic quantification or reproduction of published statistics.

The files are licensed as stated in `DATA_LICENSE.txt`. They are not an independent validation set.
