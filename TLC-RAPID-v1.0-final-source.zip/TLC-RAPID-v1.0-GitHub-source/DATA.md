# Data

Five author-supplied TLC workflow images and their applied standard amounts are included in `example_data/`. They are demonstrations, not a performance benchmark. See `example_data/DATA_LICENSE.txt`.

Development, validation and independent-test datasets and split manifests are not distributed with this baseline. No detection-accuracy or quantitative-accuracy result is claimed for this source snapshot. Verify plate/batch separation and use independently annotated data when evaluating the complete workflow.

Images and results supplied by users retain their own ownership and licensing. Running this software does not change those rights.
