# Model weights

The baseline includes `weights/best.pt`.

- Format: PyTorch checkpoint containing a YOLOv5 segmentation model.
- File size: 15,361,187 bytes.
- SHA-256: `E507240E8C7BB8E8C3C57ABB20ADEE6FEBA78670F2EDF6E06BCF1AE12A4440A5`.
- License: AGPL-3.0-only, supplied together with the source.
- Class mapping: `weights/boCenColor.yaml`; the loader checks that it agrees with the model.

The model is loaded locally; no weight download is required. The expected digest is in `analysis_settings.csv`. Checkpoint deserialization can execute Python code, so only trusted model files and independently verified digests should be used.

PowerShell integrity check:

```powershell
Get-FileHash weights/best.pt -Algorithm SHA256
```

See `MODEL_CARD.md` for scope and available training provenance. Original image data are not contained in this inference checkpoint.
