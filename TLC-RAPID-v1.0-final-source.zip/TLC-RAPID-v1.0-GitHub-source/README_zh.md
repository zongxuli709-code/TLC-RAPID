# TLC-RAPID v1.0

TLC-RAPID 用于薄层色谱斑点分割和同板标准品校准，输入为可见光、254 nm 或 366 nm 条件下采集的 8 位彩色静态图像。完整算法说明见 [README.md](README.md)。

## 安装与运行

参考环境为 Windows x64、Python 3.12。本源码包包含模型和五张示例图，不包含 Python 解释器或 exe。

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run_analysis.py
```

默认打开图形界面。激活虚拟环境后也可以双击 `run_analysis.bat`。默认使用 CPU，运行依赖锁定在 `requirements-lock.txt`；其他系统、Python 版本和 GPU 环境需单独验证。

## 输入

1. 图片放入 `user_input/images/`，支持 JPG、JPEG、PNG、BMP、TIF、TIFF、WEBP。灰度、透明通道或 16 位图像需先明确转换为 8 位三通道彩色图像。
2. 填写 `user_input/standard_concentrations.csv`。此文件沿用常用名称，但实际输入的是**每条带施加量，单位 ug/band（微克/条带）**，不是溶液浓度。模板不预填标准品数值。
3. 检查 `analysis_settings.csv`，选择成像模式和校准方法后运行。

```csv
image_filename,standard_1,standard_2,standard_3,standard_4,standard_5,amount_unit,imaging_mode,notes
plate.png,0.5,1,2,3,4,ug/band,visible,标准品从左到右
```

文件名须包含扩展名，匹配不区分大小写。只有显式填写 `(default)` 行时才会使用默认行。标准品列按编号排序，不允许内部空值、非有限数值、负数或重复施加量；尾部未使用的标准品列可以留空。二次拟合至少需要 4 个标准水平，线性拟合至少需要 3 个，另需至少 1 个样品。

换算公式：`施加量（ug/band）= 溶液浓度（mg/mL）× 点样体积（uL）`。结果不自动换算为样品溶液浓度或药材含量，后续换算需使用实际点样体积、稀释倍数和样品制备记录。

## 人工复核

默认 ROI 为原图 130 × 35 像素，检测置信度为 0.15，NMS IoU 为 0.30，模型输入尺寸为 640。目标行以最左侧检出点为基准，纵向容差为 60 像素。程序按横坐标排序，将前 N 个 ROI 视为标准品，其余视为样品；这种版面假设不能替代人工确认。

复核窗口中：左键空白处加框，拖动已有框移动，右键已有框删除，S 接受，Esc 或关闭窗口放弃本次修改。自动框也可删除和移动，零检出图片也能补框。未修改的自动框保留模型掩膜；新增或移动的框使用整块矩形积分，并明确记录为 `manual_rectangle`。两种积分区域不同，研究中需报告人工操作情况。

无交互运行：

```powershell
.\.venv\Scripts\python.exe run_analysis.py --run
.\.venv\Scripts\python.exe run_analysis.py --run --manual-mark
.\.venv\Scripts\python.exe run_analysis.py --run --input-dir example_data
```

`--run` 本身不弹窗、不等待输入；`--manual-mark` 显式开启逐图复核。`--input-dir` 选择完整输入目录，`--output-dir` 指定结果目录的上级目录。

## 定量规则

测量始终使用未标注的原图像素，掩膜坐标与原图一致。所有 ROI 共用水平带背景；背景取中心线 ±45 像素范围，排除 ROI 及其左右各 10 像素后取中位数。有效背景少于 80 像素时拒绝定量。

- 366 nm 使用 IGI：掩膜内 `max(灰度－背景, 0)` 的总和。
- 可见光或 254 nm 使用 IOD：掩膜内 `max(log10(背景/max(灰度,1)),0)` 的总和。`IOD` 与 `Sum_OD` 一致。
- 色彩指标是固定 ROI 的描述性均值，不参与校准。饱和像素数及 ROI 越界情况单独记录。

建议明确填写实际成像模式；auto 只是基于边缘颜色的启发式判断，不能判断采集波长。标准品表中的逐图成像模式优先于全局设置。

校准采用非加权最小二乘。二次曲线在标准区间内转向、标准品 ROI 越界、响应退化或随量下降、R² 低于 0.75 等情况将被拒绝。0.75 只是软件防错阈值，不是方法学验证标准。只有标准施加量区间和标准响应范围内的唯一反解才输出数值，不外推、不强选分支、不插值补值、不自动切换模型。

## 结果

每次运行新建 `runs/predict-seg/run-.../`。Excel 包含 Metadata、Results、Image_Status 三张表。读取 `Calculated_Amount_Per_Band` 时须同时查看 `Amount_Unit`、`Quantification_Status` 和范围原因；无有效结果时单元格留空。

逐图文件夹保存标注图、检测记录、最终 ROI、裁剪掩膜、测量结果及状态；校准成功时还保存完整系数和曲线图。输入哈希、配置、模型哈希、源码内容哈希及运行环境写入 JSON 和 Metadata，便于追溯。退出码 0 表示全部成功，2 表示部分成功，1 表示无图像得到有效定量样品结果或启动失败。

五张示例只演示流程，并非验证集。默认配置可能因漏检、范围外响应或非单调曲线而拒绝部分结果，不能据此承诺全部自动定量。任何发表数据仍需核对原始实验记录和方法学验证。

## 代码组织与许可

应用逻辑按配置、检测、测量、校准、复核、导出和流程编排拆分于 `tlc/`。`models/` 和大部分 `utils/` 保留 YOLOv5 支持代码及模型反序列化所需模块路径。

软件和随附模型采用 AGPL-3.0-only，第三方许可见 `THIRD_PARTY_NOTICES.txt` 和 `THIRD_PARTY_LICENSES/`。
