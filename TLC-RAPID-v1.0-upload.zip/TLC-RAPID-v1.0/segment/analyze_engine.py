# Ultralytics YOLOv5 🚀, AGPL-3.0 license
"""
Run YOLOv5 segmentation inference on images, videos, directories, streams, etc.

Usage - sources:
    $ python segment/predict.py --weights yolov5s-seg.pt --source 0                               # webcam
                                                                  img.jpg                         # image
                                                                  vid.mp4                         # video
                                                                  screen                          # screenshot
                                                                  path/                           # directory
                                                                  list.txt                        # list of images
                                                                  list.streams                    # list of streams
                                                                  'path/*.jpg'                    # glob
                                                                  'https://youtu.be/LNwODJXcvt4'  # YouTube
                                                                  'rtsp://example.com/media.mp4'  # RTSP, RTMP, HTTP stream

Usage - formats:
    $ python segment/predict.py --weights yolov5s-seg.pt                 # PyTorch
                                          yolov5s-seg.torchscript        # TorchScript
                                          yolov5s-seg.onnx               # ONNX Runtime or OpenCV DNN with --dnn
                                          yolov5s-seg_openvino_model     # OpenVINO
                                          yolov5s-seg.engine             # TensorRT
                                          yolov5s-seg.mlmodel            # CoreML (macOS-only)
                                          yolov5s-seg_saved_model        # TensorFlow SavedModel
                                          yolov5s-seg.pb                 # TensorFlow GraphDef
                                          yolov5s-seg.tflite             # TensorFlow Lite
                                          yolov5s-seg_edgetpu.tflite     # TensorFlow Edge TPU
                                          yolov5s-seg_paddle_model       # PaddlePaddle
"""

import argparse
import json
import platform
import sys
from datetime import datetime
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score
from scipy import stats

import torch

from app_metadata import build_provenance
from utils.calibration_safety import inspect_quadratic_domain

FILE = Path(__file__).resolve()
CALIBRATION_R2_WARNING_THRESHOLD = 0.75
if getattr(sys, "frozen", False):
    ROOT = Path(sys.executable).resolve().parent
else:
    ROOT = FILE.parents[1]
    if str(ROOT) not in sys.path:
        sys.path.append(str(ROOT))

from ultralytics.utils.plotting import Annotator, colors, save_one_box

from models.common import DetectMultiBackend
from utils.dataloaders import IMG_FORMATS, VID_FORMATS, LoadImages, LoadScreenshots, LoadStreams
from utils.general import (
    LOGGER,
    Profile,
    check_file,
    check_img_size,
    check_imshow,
    check_requirements,
    colorstr,
    cv2,
    increment_path,
    non_max_suppression,
    print_args,
    scale_boxes,
    scale_segments,
    strip_optimizer,
    yaml_save,
)
from utils.augmentations import letterbox
from utils.segment.general import masks2segments, process_mask, process_mask_native
from utils.torch_utils import select_device, smart_inference_mode


def choose_reference_y_from_boxes_xyxy(boxes: np.ndarray, y_tolerance: int = 60) -> int | None:
    """
    改进版：优先使用"最左侧点"的 y 坐标作为参考，确保左边点不被遮盖。
    如果第一次检测时左边点没有被检测到，则使用所有检测点的 y 坐标中位数。
    
    这样即使左边有些斑点稍微偏离，也能被包含在水平带内。
    """
    if boxes is None or len(boxes) == 0:
        return None
    boxes = np.asarray(boxes)
    x_centers = ((boxes[:, 0] + boxes[:, 2]) / 2.0).astype(float)
    y_centers = ((boxes[:, 1] + boxes[:, 3]) / 2.0).astype(float)
    
    if len(boxes) >= 1:
        # 优先使用最左侧点的 y 坐标（确保左边点不被遮盖）
        idx_leftmost = int(np.argmin(x_centers))
        y_ref_leftmost = float(y_centers[idx_leftmost])
        
        # 如果点数足够多，检查是否有其他点与最左侧点在同一水平带内
        if len(boxes) >= 2:
            in_band = np.abs(y_centers - y_ref_leftmost) <= float(y_tolerance)
            in_band_indices = np.where(in_band)[0]
            
            if len(in_band_indices) >= 2:
                # 使用同一水平带内所有点的 y 坐标中位数（更稳定）
                y_ref_median = float(np.median(y_centers[in_band_indices]))
                return int(round(y_ref_median))
        
        # 如果点数太少或没有足够的点在同一水平带，使用最左侧点
        return int(round(y_ref_leftmost))
    else:
        # 只有一个点，直接使用它的 y 坐标
        return int(round(float(y_centers[0])))


def get_solid_fill_color(im0_bgr: np.ndarray, mode: str = "background") -> tuple[int, int, int]:
    """
    获取遮盖用的纯色 (B, G, R)。
    - background: 用图像整体均值颜色（更贴近背景）
    - white/black: 纯白/纯黑
    """
    mode = (mode or "background").lower()
    if mode == "white":
        return (255, 255, 255)
    if mode == "black":
        return (0, 0, 0)
    # background
    b, g, r, _ = cv2.mean(im0_bgr)
    return (int(round(b)), int(round(g)), int(round(r)))


def mask_outside_band(
    im0_bgr: np.ndarray,
    boxes_xyxy: np.ndarray,
    y_ref: int,
    y_tolerance: int,
    pad: int = 6,
    color_mode: str = "background",
    x_limit: int | None = None,
) -> np.ndarray:
    """
    在"筛选斑点之前"先做一次**整行遮盖**：
    - 仅保留 [y_ref - y_tolerance, y_ref + y_tolerance] 这一水平带上的信息
    - 该带之外的整行像素全部用纯色覆盖，从根源上去掉上下干扰斑点
    - 与检测框无关，避免"先用框再筛选"导致漏点

    为了兼容旧接口，这里仍保留 boxes_xyxy 和 x_limit 参数，但当前实现不再依赖它们。
    """
    if im0_bgr is None or y_ref is None:
        return im0_bgr

    h, w = im0_bgr.shape[:2]
    fill = get_solid_fill_color(im0_bgr, color_mode)
    out = im0_bgr.copy()

    band_half = max(int(y_tolerance), 0)
    y_center = int(y_ref)
    y1_band = max(0, y_center - band_half)
    y2_band = min(h, y_center + band_half)

    # 覆盖 band 之上的所有行
    if y1_band > 0:
        out[0:y1_band, :] = fill

    # 覆盖 band 之下的所有行
    if y2_band < h:
        out[y2_band:h, :] = fill

    return out


def preprocess_im0_for_model(im0_bgr: np.ndarray, img_size, stride: int, auto: bool):
    """
    将 im0(BGR) 按 YOLOv5 的 LoadImages 逻辑 letterbox + BGR->RGB + HWC->CHW。
    返回: (im_chw_rgb_contiguous, im_letterbox_bgr)
    """
    im_lb = letterbox(im0_bgr, img_size, stride=stride, auto=auto)[0]  # padded resize (BGR)
    im = im_lb.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
    im = np.ascontiguousarray(im)
    return im, im_lb


def rect_from_center(cx, cy, fw, fh, img_w, img_h):
    """以中心点生成固定大小矩形，并限制在图像范围内。"""
    x1 = int(cx - fw // 2)
    y1 = int(cy - fh // 2)
    x2 = x1 + int(fw)
    y2 = y1 + int(fh)
    if x1 < 0:
        x2 -= x1
        x1 = 0
    if y1 < 0:
        y2 -= y1
        y1 = 0
    if x2 > img_w:
        shift = x2 - img_w
        x1 = max(0, x1 - shift)
        x2 = img_w
    if y2 > img_h:
        shift = y2 - img_h
        y1 = max(0, y1 - shift)
        y2 = img_h
    return [x1, y1, x2, y2]


def _rect_hit_test(rect, x, y, margin=6):
    x1, y1, x2, y2 = rect
    return (x1 - margin) <= x <= (x2 + margin) and (y1 - margin) <= y <= (y2 + margin)


def _manual_mark_help_canvas(box_count: int) -> np.ndarray:
    """Fixed-size help panel (not drawn on the TLC image, so it will not stretch)."""
    canvas = np.full((300, 720, 3), 32, dtype=np.uint8)
    lines = [
        ("MANUAL MARK - how to edit boxes", (255, 255, 255), 0.85, 2),
        ("Green AUTO = already detected", (200, 200, 200), 0.65, 1),
        ("", (0, 0, 0), 0.5, 1),
        ("Left-click  =  ADD box", (220, 220, 220), 0.75, 2),
        ("Right-click =  DELETE box", (220, 220, 220), 0.75, 2),
        ("", (0, 0, 0), 0.5, 1),
        ("NEXT: press S to save and continue", (0, 255, 255), 0.78, 2),
        ("Esc = skip (keep auto only)", (180, 180, 255), 0.65, 1),
        ("", (0, 0, 0), 0.5, 1),
        (f"Manual boxes added: {box_count}", (160, 255, 160), 0.7, 2),
        ("Click the IMAGE window, then use mouse / keys", (170, 170, 170), 0.55, 1),
    ]
    y = 36
    for text, color, scale, thickness in lines:
        if text:
            cv2.putText(canvas, text, (24, y), cv2.FONT_HERSHEY_SIMPLEX, scale, color, thickness, cv2.LINE_AA)
        y += 28 if text else 12
    cv2.rectangle(canvas, (8, 8), (711, 291), (0, 200, 255), 2)
    return canvas


def select_manual_rectangles(
        image_bgr: np.ndarray,
        window_name: str = "Manual Mark Spots",
        fixed_width: int = 130,
        fixed_height: int = 35,
) -> list[list[int]]:
    """
    Manual marking: box size matches auto detection (fixed_width x fixed_height).
    Controls:
    - Left-click: add a fixed-size box centred on the click
    - Right-click: delete a box (or undo last if clicking empty area)
    - Left-drag a yellow box: move it
    - Delete / D: delete selected box
    - S: save and continue to the next image
    - ESC: skip manual boxes for this image
    """
    if image_bgr is None or image_bgr.size == 0:
        return []

    h, w = image_bgr.shape[:2]
    base = image_bgr.copy()
    rectangles: list[list[int]] = []
    state = {
        "selected": -1,
        "dragging": False,
        "drag_offset_x": 0,
        "drag_offset_y": 0,
        "hover": None,
    }
    help_window = "Manual Mark - Help"

    def clamp_point(x, y):
        return max(0, min(x, w - 1)), max(0, min(y, h - 1))

    def find_rect_at(x, y):
        for idx in range(len(rectangles) - 1, -1, -1):
            if _rect_hit_test(rectangles[idx], x, y):
                return idx
        return -1

    def on_mouse(event, x, y, flags, param):
        x, y = clamp_point(x, y)
        if event == cv2.EVENT_MOUSEMOVE:
            state["hover"] = (x, y)
            if state["dragging"] and state["selected"] >= 0:
                cx = x - state["drag_offset_x"]
                cy = y - state["drag_offset_y"]
                rectangles[state["selected"]] = rect_from_center(cx, cy, fixed_width, fixed_height, w, h)
        elif event == cv2.EVENT_LBUTTONDOWN:
            hit = find_rect_at(x, y)
            if hit >= 0:
                state["selected"] = hit
                rcx = (rectangles[hit][0] + rectangles[hit][2]) // 2
                rcy = (rectangles[hit][1] + rectangles[hit][3]) // 2
                state["drag_offset_x"] = x - rcx
                state["drag_offset_y"] = y - rcy
                state["dragging"] = True
            else:
                rectangles.append(rect_from_center(x, y, fixed_width, fixed_height, w, h))
                state["selected"] = len(rectangles) - 1
        elif event == cv2.EVENT_LBUTTONUP:
            state["dragging"] = False
        elif event == cv2.EVENT_RBUTTONDOWN:
            hit = find_rect_at(x, y)
            if hit >= 0:
                rectangles.pop(hit)
                if state["selected"] == hit:
                    state["selected"] = -1
                elif state["selected"] > hit:
                    state["selected"] -= 1
            elif rectangles:
                rectangles.pop()
                state["selected"] = min(state["selected"], len(rectangles) - 1)

    def _draw_status_bar(canvas: np.ndarray) -> None:
        # Short bar only - font scales with image width so it stays readable
        scale = float(np.clip(w / 1100.0, 0.7, 1.6))
        thickness = 2 if scale < 1.1 else 3
        bar_h = int(42 * scale)
        overlay = canvas.copy()
        cv2.rectangle(overlay, (0, 0), (w - 1, bar_h), (20, 20, 20), -1)
        cv2.addWeighted(overlay, 0.65, canvas, 0.35, 0, canvas)
        text = f"Left=ADD   Right=DELETE   S=NEXT   Esc=SKIP   (+{len(rectangles)})"
        cv2.putText(
            canvas, text, (12, int(28 * scale)),
            cv2.FONT_HERSHEY_SIMPLEX, scale * 0.7, (0, 255, 255), thickness, cv2.LINE_AA,
        )

    # Help window: fixed pixel size, AUTOSIZE so text is never stretched
    cv2.namedWindow(help_window, cv2.WINDOW_AUTOSIZE)
    cv2.imshow(help_window, _manual_mark_help_canvas(0))

    # Image window: keep aspect ratio when fitting to screen
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    fit = min(1280 / max(w, 1), 720 / max(h, 1), 1.0)
    cv2.resizeWindow(window_name, max(400, int(w * fit)), max(240, int(h * fit)))
    cv2.setMouseCallback(window_name, on_mouse)

    print(
        "\n===== Manual Mark =====\n"
        f"Image window: {window_name}\n"
        "Help window : Manual Mark - Help  (keep it open; text will not stretch)\n"
        "  Left-click  = ADD box\n"
        "  Right-click = DELETE box\n"
        "  S           = SAVE and go to NEXT image\n"
        "  Esc         = SKIP manual boxes for this image\n"
        "========================\n"
    )

    while True:
        canvas = base.copy()
        for idx, (x1, y1, x2, y2) in enumerate(rectangles):
            color = (0, 255, 255) if idx == state["selected"] else (0, 200, 255)
            thickness = 3 if idx == state["selected"] else 2
            cv2.rectangle(canvas, (x1, y1), (x2, y2), color, thickness)
            cv2.putText(canvas, f"M{idx + 1}", (x1, max(15, y1 - 5)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)

        if state["hover"] and state["selected"] < 0 and not state["dragging"]:
            hx, hy = state["hover"]
            if find_rect_at(hx, hy) < 0:
                px1, py1, px2, py2 = rect_from_center(hx, hy, fixed_width, fixed_height, w, h)
                cv2.rectangle(canvas, (px1, py1), (px2, py2), (255, 255, 0), 1)

        _draw_status_bar(canvas)
        cv2.imshow(window_name, canvas)
        cv2.imshow(help_window, _manual_mark_help_canvas(len(rectangles)))

        key = cv2.waitKey(20) & 0xFF
        if key in (ord("s"), ord("S")):
            break
        if key in (8, 127, ord("d"), ord("D")):
            if 0 <= state["selected"] < len(rectangles):
                rectangles.pop(state["selected"])
                state["selected"] = -1
            elif rectangles:
                rectangles.pop()
        if key == 27:
            rectangles = []
            break

    cv2.setMouseCallback(window_name, lambda *args: None)
    for name in (window_name, help_window):
        try:
            cv2.destroyWindow(name)
        except Exception:
            pass
    return [rect_from_center(
        (r[0] + r[2]) // 2, (r[1] + r[3]) // 2, fixed_width, fixed_height, w, h
    ) for r in rectangles]


def process_manual_rectangles(gray_im, color_im, manual_rects, start_spot_idx=0, fixed_width=130, fixed_height=35):
    """将手动矩形转换为和自动检测一致的特征结果（固定 ROI 大小）。"""
    if gray_im is None or color_im is None:
        return []
    h, w = gray_im.shape[:2]
    global_mean_bg = float(np.median(gray_im)) if gray_im.size > 0 else 1.0

    prepared = []
    for i, rect in enumerate(manual_rects):
        cx = (int(rect[0]) + int(rect[2])) // 2
        cy = (int(rect[1]) + int(rect[3])) // 2
        x1, y1, x2, y2 = rect_from_center(cx, cy, fixed_width, fixed_height, w, h)
        if x2 <= x1 or y2 <= y1:
            continue
        roi_gray = gray_im[y1:y2, x1:x2]
        roi_color = color_im[y1:y2, x1:x2]
        if roi_gray.size == 0:
            continue
        prepared.append({
            "i": i, "cx": cx, "cy": cy, "box": [x1, y1, x2, y2],
            "roi_gray": roi_gray, "roi_color": roi_color,
            "mean_fg": float(roi_gray.mean()),
        })

    lane_bg = estimate_lane_background(gray_im, [p["box"] for p in prepared])
    polarity = detect_signal_polarity([p["mean_fg"] for p in prepared], lane_bg)
    results = []
    for item in prepared:
        i, cx, cy = item["i"], item["cx"], item["cy"]
        x1, y1, x2, y2 = item["box"]
        roi_gray, roi_color = item["roi_gray"], item["roi_color"]
        mean_fg = item["mean_fg"]
        sum_gray = int(roi_gray.sum())

        local_bg = calculate_local_background(gray_im, [x1, y1, x2, y2], margin=15)
        bg_use = lane_bg
        sum_gray_corrected, mean_gray_corrected, _ = compute_net_integral(
            roi_gray, bg_use, None, polarity=polarity
        )
        sum_od, mean_od = compute_masked_od(roi_gray, bg_use, None)
        sum_od_global, mean_od_global = compute_masked_od(roi_gray, global_mean_bg, None)
        sum_od_local, mean_od_local = compute_masked_od(roi_gray, local_bg, None)
        od_method = "lane_shared"

        if roi_color.size > 0:
            avg_B = np.mean(roi_color[:, :, 0])
            avg_G = np.mean(roi_color[:, :, 1])
            avg_R = np.mean(roi_color[:, :, 2])
            hsv_roi = cv2.cvtColor(roi_color, cv2.COLOR_BGR2HSV)
            avg_H = np.mean(hsv_roi[:, :, 0])
            avg_S = np.mean(hsv_roi[:, :, 1])
            avg_V = np.mean(hsv_roi[:, :, 2])
            lab_roi = cv2.cvtColor(roi_color, cv2.COLOR_BGR2Lab)
            avg_L = np.mean(lab_roi[:, :, 0])
            avg_A = np.mean(lab_roi[:, :, 1])
            avg_B_lab = np.mean(lab_roi[:, :, 2])
            C_map = np.sqrt(lab_roi[:, :, 1].astype(float) ** 2 + lab_roi[:, :, 2].astype(float) ** 2)
            avg_C = np.mean(C_map)
        else:
            avg_R, avg_G, avg_B = 0, 0, 0
            avg_H, avg_S, avg_V = 0, 0, 0
            avg_L, avg_A, avg_B_lab, avg_C = 0, 0, 0, 0

        ratio_local = mean_fg / local_bg if local_bg > 0 else 0
        ratio_global = mean_fg / global_mean_bg if global_mean_bg > 0 else 0
        ratio_lane = mean_fg / bg_use if bg_use > 0 else 0
        results.append({
            "Image": "",
            "Spot_Index": start_spot_idx + i,
            "Original_Index": -1,
            "X_Position": cx,
            "Y_Position": cy,
            "Width": int(fixed_width),
            "Height": int(fixed_height),
            "Area": int(fixed_width * fixed_height),
            "Mean_Gray": round(float(mean_fg), 2),
            "Sum_Gray": sum_gray,
            "Sum_Gray_Corrected": round(float(sum_gray_corrected), 2),
            "Mean_Gray_Corrected": round(float(mean_gray_corrected), 2),
            "Net_Signal": round(float(sum_gray_corrected), 2),
            "Signal_Polarity": polarity,
            "Lane_Background": round(float(bg_use), 2),
            "Mean_OD": round(float(mean_od), 4),
            "Sum_OD": round(float(sum_od), 4),
            "Mean_OD_Global": round(float(mean_od_global), 4),
            "Sum_OD_Global": round(float(sum_od_global), 4),
            "Mean_OD_Local": round(float(mean_od_local), 4),
            "Sum_OD_Local": round(float(sum_od_local), 4),
            "OD_Method": od_method,
            "IOD": round(float(sum_od_global), 4),
            "Peak_Area": 0.0,
            "Baseline_Peak": round(float(bg_use), 2),
            "Global_Background": round(float(global_mean_bg), 2),
            "Local_Background": round(float(local_bg), 2),
            "Gray_Ratio_Global": round(float(ratio_global), 4),
            "Gray_Ratio_Local": round(float(ratio_local), 4),
            "Gray_Ratio_Lane": round(float(ratio_lane), 4),
            "Center_Point": f"{cx},{cy}",
            "R": round(float(avg_R), 2),
            "G": round(float(avg_G), 2),
            "B": round(float(avg_B), 2),
            "H": round(float(avg_H), 2),
            "S": round(float(avg_S), 2),
            "V": round(float(avg_V), 2),
            "L": round(float(avg_L), 2),
            "A": round(float(avg_A), 2),
            "B_lab": round(float(avg_B_lab), 2),
            "C": round(float(avg_C), 2),
            "Spot_Type": "",
            "Known_Concentration": None,
            "Calculated_Concentration": None,
            "Calculated_Amount_Per_Band": None,
            "Spot_Source": "manual",
            "Manual_Rect": f"{x1},{y1},{x2},{y2}",
        })
    return results


def calculate_optical_density(gray_im, global_bg):
    """
    计算光密度值 - 修正版本
    OD = log10(背景强度 / 样品强度)
    """
    # 确保输入有效
    if gray_im.size == 0 or global_bg <= 0:
        return np.zeros_like(gray_im, dtype=float)

    # 将图像转换为浮点数
    gray_im_float = gray_im.astype(float)

    # 避免除零错误 - 将零值设为很小的正数
    gray_im_float[gray_im_float == 0] = 1e-10

    # 避免背景为零
    if global_bg <= 0:
        global_bg = 1e-10

    # 计算光密度
    try:
        od_map = np.log10(global_bg / gray_im_float)

        # 检查异常值
        if np.any(np.isnan(od_map)) or np.any(np.isinf(od_map)):
            print("Warning: OD calculation produced invalid values")
            # 将异常值设为0
            od_map = np.nan_to_num(od_map, nan=0.0, posinf=0.0, neginf=0.0)

        # 将负值设为0（物理上不可能为负）
        od_map[od_map < 0] = 0

        return od_map
    except Exception as e:
        print(f"OD calculation error: {e}")
        return np.zeros_like(gray_im_float)


def analyze_image_statistics(gray_im, color_im):
    """
    分析图像统计信息，帮助诊断问题
    """
    print("\n=== Image statistics ===")
    print(f"Image shape: {gray_im.shape}")
    print(f"Gray range: [{gray_im.min()}, {gray_im.max()}]")
    print(f"Gray mean: {gray_im.mean():.2f}")
    print(f"Gray std dev: {gray_im.std():.2f}")

    # 检查是否有异常值
    unique_vals = np.unique(gray_im)
    print(f"Unique gray levels: {len(unique_vals)}")
    print(f"First 10 unique values: {unique_vals[:10]}")

    # 检查彩色图像统计
    if color_im is not None:
        print(f"Color image shape: {color_im.shape}")
        print(f"R channel range: [{color_im[:, :, 0].min()}, {color_im[:, :, 0].max()}]")
        print(f"G channel range: [{color_im[:, :, 1].min()}, {color_im[:, :, 1].max()}]")
        print(f"B channel range: [{color_im[:, :, 2].min()}, {color_im[:, :, 2].max()}]")

    # 检查图像是否过暗或过亮
    if gray_im.mean() < 30:
        print("Warning: image may be underexposed")
    elif gray_im.mean() > 220:
        print("Warning: image may be overexposed")

    print("==================\n")


def detect_background_type(color_im: np.ndarray) -> str:
    """
    检测图像背景类型。
    - 蓝色背景：返回 'blue'
    - 其他颜色背景（白/绿等）：返回 'other'
    """
    if color_im is None or color_im.size == 0:
        return "other"

    h, w = color_im.shape[:2]
    margin = max(8, min(h, w) // 12)
    strips = [
        color_im[:margin, :],
        color_im[-margin:, :],
        color_im[:, :margin],
        color_im[:, -margin:],
    ]
    bg_pixels = np.vstack([s.reshape(-1, 3) for s in strips if s.size > 0]).astype(np.float32)
    if bg_pixels.size == 0:
        return "other"

    mean_b, mean_g, mean_r = bg_pixels.mean(axis=0)
    hsv = cv2.cvtColor(bg_pixels.reshape(-1, 1, 3).astype(np.uint8), cv2.COLOR_BGR2HSV).reshape(-1, 3)
    mean_h, mean_s, mean_v = hsv.mean(axis=0)

    blue_by_channel = mean_b > mean_r + 12 and mean_b > mean_g + 8 and mean_b > 80
    blue_by_hue = 90 <= mean_h <= 135 and mean_s > 35 and mean_v > 35
    if blue_by_channel or blue_by_hue:
        return "blue"
    return "other"


def get_calibration_y_axis_for_background(background_type: str) -> tuple[str, str]:
    """按论文策略：366 nm 荧光板用 IGI，可见光/254 nm 用 IOD。"""
    if background_type == "blue":
        return "sum_gray", "IGI (gray integral)"
    return "sum_od", "IOD (total optical density)"


def _is_degenerate_response(vals) -> tuple[bool, float, float]:
    """判断响应序列是否退化（大量为 0 或几乎无动态范围）。"""
    vals = np.asarray(vals, dtype=float)
    if vals.size < 2:
        return True, 0.0, 0.0
    nonzero_ratio = float(np.mean(np.abs(vals) > 1e-9))
    dyn = float(np.ptp(vals))
    scale = float(np.median(np.abs(vals[np.abs(vals) > 1e-9]))) if nonzero_ratio > 0 else 0.0
    degenerate = nonzero_ratio < 0.6 or dyn <= max(1e-6, 0.01 * scale)
    return degenerate, nonzero_ratio, dyn


def resolve_imaging_profile(imaging_mode: str, color_im: np.ndarray) -> str:
    """确定背景类型：blue=366nm 荧光板，other=可见光/254nm 吸收板。"""
    try:
        from utils.load_user_config import normalize_imaging_mode
        mode = normalize_imaging_mode(imaging_mode)
    except Exception:
        mode = str(imaging_mode or "auto").strip().lower()

    if mode == "366nm":
        return "blue"
    if mode in ("visible", "254nm"):
        return "other"
    return detect_background_type(color_im)


def _spearman_abs(conc, vals) -> float:
    """浓度与响应的 |Spearman|，无效时返回 0。"""
    conc = np.asarray(conc, dtype=float)
    vals = np.asarray(vals, dtype=float)
    if conc.size < 2 or vals.size < 2 or conc.size != vals.size:
        return 0.0
    try:
        rho = abs(float(stats.spearmanr(conc, vals).correlation))
    except Exception:
        return 0.0
    return rho if np.isfinite(rho) else 0.0


def select_paper_response_axis(
    standard_results,
    concentrations,
    background_type: str,
) -> tuple[str, str, str, float]:
    """
    论文优先的响应指标选择：
    - 366nm/blue：默认 IGI(sum_gray)；若 IGI 退化，或 IGI 单调性差于 peak_1d，则备选 peak_1d
    - 可见光/254nm/other：固定 IOD(sum_od)
    返回: y_axis_type, y_label, axis_source, |spearman|
    """
    conc = np.asarray(concentrations, dtype=float)
    mono_threshold = 0.5
    mono_margin = 0.05

    if background_type == "blue":
        igi_vals = np.asarray([_extract_y_value(r, "sum_gray") for r in standard_results], dtype=float)
        peak_vals = np.asarray([_extract_y_value(r, "peak_1d") for r in standard_results], dtype=float)
        igi_deg, nz, dyn = _is_degenerate_response(igi_vals)
        peak_deg, peak_nz, peak_dyn = _is_degenerate_response(peak_vals)
        igi_sp = _spearman_abs(conc, igi_vals)
        peak_sp = _spearman_abs(conc, peak_vals)

        use_peak = False
        axis_source = "igi"
        reason = ""

        if igi_deg and not peak_deg:
            use_peak = True
            axis_source = "peak_1d_fallback"
            reason = (
                f"IGI degraded (nonzero={nz:.2f}, dynamic range={dyn:.4g}); "
                f"peak_1d usable (nonzero={peak_nz:.2f}, dynamic range={peak_dyn:.4g})"
            )
        elif (
            not peak_deg
            and igi_sp < mono_threshold
            and peak_sp >= mono_threshold
            and peak_sp > igi_sp + mono_margin
        ):
            use_peak = True
            axis_source = "peak_1d_fallback"
            reason = (
                f"IGI weak monotonicity (|Spearman|={igi_sp:.2f}<{mono_threshold}); "
                f"peak_1d better (|Spearman|={peak_sp:.2f})"
            )
        elif igi_deg and peak_deg:
            axis_source = "igi_degraded"
            print("[Warning] Both IGI and peak_1d degraded; keeping IGI")

        if use_peak:
            y_axis_type, y_label = "peak_1d", "1D peak area (366 nm fallback)"
            print(f"[366nm fallback] {reason}; using peak_1d")
            LOGGER.warning(f"366nm fallback to peak_1d: {reason}")
        else:
            y_axis_type, y_label = "sum_gray", "IGI (gray integral)"
    else:
        y_axis_type, y_label = "sum_od", "IOD (total optical density)"
        axis_source = "iod"

    vals = np.asarray([_extract_y_value(r, y_axis_type) for r in standard_results], dtype=float)
    spearman_abs = _spearman_abs(conc, vals)

    return y_axis_type, y_label, axis_source, spearman_abs


def _extract_y_value(result: dict, y_axis_type: str) -> float:
    if y_axis_type == "peak_1d":
        return float(result.get("Peak_Area_1D", result.get("Net_Signal", 0.0)))
    if y_axis_type == "net_signal":
        return float(result.get("Net_Signal", result.get("Sum_Gray_Corrected", result.get("Sum_Gray", 0.0))))
    if y_axis_type == "sum_gray":
        return float(result.get("Sum_Gray_Corrected", result.get("Net_Signal", result.get("Sum_Gray", 0.0))))
    if y_axis_type == "mean_gray":
        return float(result.get("Mean_Gray_Corrected", result.get("Mean_Gray", 0.0)))
    if y_axis_type == "sum_od":
        return float(result.get("Sum_OD", 0.0))
    if y_axis_type == "mean_od":
        return float(result.get("Mean_OD", 0.0))
    return float(result.get("Net_Signal", result.get("Sum_Gray", 0.0)))


def _fit_polynomial(concentrations: np.ndarray, responses: np.ndarray, method: str) -> tuple[list[float], float]:
    """Return unified [a, b, c] coefficients and R2 for quadratic or linear regression."""
    fitted = np.polyfit(concentrations, responses, deg=2 if method == "quadratic" else 1)
    if method == "quadratic":
        a, b, c = (float(value) for value in fitted)
    else:
        b, c = (float(value) for value in fitted)
        a = 0.0
        if abs(b) < 1e-12:
            raise ValueError("Linear calibration failed because the fitted slope is zero")
    coefs = [a, b, c]
    predicted = np.polyval(coefs, concentrations)
    r_squared = float(r2_score(responses, predicted)) if len(np.unique(responses)) > 1 else 0.0
    return coefs, r_squared


def fit_calibration_model(standard_results, standard_concentrations, y_axis_type="sum_od",
                          y_label: str | None = None,
                          quantification_method: str = "quadratic"):
    """Fit the requested calibration curve and prepare an explicit fallback.

    A quadratic fit is retained even when its vertex lies in the standard
    range. Ambiguous inverse solutions are resolved separately for each sample
    from the same-plate standards; linear regression is used only when that
    sample has no objectively selectable quadratic root.
    """
    if len(standard_results) != len(standard_concentrations):
        raise ValueError("Standard count does not match concentration list length")
    requested_method = str(quantification_method or "quadratic").strip().lower()
    if requested_method not in ("quadratic", "linear"):
        requested_method = "quadratic"
    required_count = 4 if requested_method == "quadratic" else 3
    if len(standard_results) < required_count:
        raise ValueError(f"{requested_method.capitalize()} calibration requires at least {required_count} standard points")

    if y_label is None:
        _, y_label = get_calibration_y_axis_for_background(
            "blue" if y_axis_type in ("sum_gray", "net_signal") else "other"
        )

    concentrations = np.array(standard_concentrations, dtype=float)
    y_values = np.array([_extract_y_value(r, y_axis_type) for r in standard_results], dtype=float)

    # 左右顺序仅检查并报错；绝不静默重标标准品。
    order_reversed = False
    try:
        spearman_fwd = float(stats.spearmanr(concentrations, y_values).correlation)
        spearman_rev = float(stats.spearmanr(concentrations[::-1], y_values).correlation)
    except Exception:
        spearman_fwd, spearman_rev = 0.0, 0.0
    if not np.isfinite(spearman_fwd):
        spearman_fwd = 0.0
    if not np.isfinite(spearman_rev):
        spearman_rev = 0.0

    if spearman_rev > 0.65 and spearman_fwd < 0.35 and (spearman_rev - spearman_fwd) > 0.35:
        raise ValueError(
            "Standard concentration order appears reversed relative to the measured response "
            f"(forward Spearman={spearman_fwd:.3f}, reversed={spearman_rev:.3f}). "
            "Verify the left-to-right concentration entries; TLC-RAPID will not relabel standards automatically."
        )
    else:
        print(f"Standard monotonicity: Spearman(conc, response)={spearman_fwd:.3f}")

    method = requested_method
    method_selection = method
    coefs, r_squared = _fit_polynomial(concentrations, y_values, method)
    a, b, c = coefs
    quadratic_domain = inspect_quadratic_domain(a, b, float(concentrations.min()), float(concentrations.max()))
    if method == "quadratic" and quadratic_domain.vertex_in_range:
        LOGGER.warning(
            f"Quadratic vertex {quadratic_domain.vertex:.6g} lies inside the standard range "
            f"{float(concentrations.min()):.6g}-{float(concentrations.max()):.6g}; "
            "sample roots will be selected using the same-plate standards."
        )
    linear_fallback_coefs = None
    linear_fallback_r2 = None
    if method == "quadratic":
        try:
            linear_fallback_coefs, linear_fallback_r2 = _fit_polynomial(
                concentrations, y_values, "linear"
            )
        except ValueError:
            LOGGER.warning("Linear fallback is unavailable because its fitted slope is zero")
    calibration_quality = "acceptable" if r_squared >= CALIBRATION_R2_WARNING_THRESHOLD else "poor_fit"
    if calibration_quality == "poor_fit":
        LOGGER.warning(
            f"Calibration R2={r_squared:.4f} is below the warning threshold "
            f"{CALIBRATION_R2_WARNING_THRESHOLD:.2f}; review standards and detected spots"
        )

    calibration_params = {
        "fit_type": method,
        "quantification_method": method,
        "method_selection": method_selection,
        "requested_method": requested_method,
        "coefs": coefs,
        "a": a,
        "b": b,
        "c": c,
        "r_squared": float(r_squared),
        "calibration_quality": calibration_quality,
        "y_axis_type": y_axis_type,
        "y_label": y_label,
        "x_label": "Concentration",
        "background_type": "blue" if y_axis_type in ("sum_gray", "net_signal") else "other",
        "X_original": concentrations.tolist(),
        "y_original": y_values.tolist(),
        "conc_min": float(concentrations.min()),
        "conc_max": float(concentrations.max()),
        "y_min": float(y_values.min()),
        "y_max": float(y_values.max()),
        "spearman": float(spearman_fwd),
        "order_reversed": order_reversed,
        "quadratic_vertex": quadratic_domain.vertex,
        "quadratic_vertex_in_range": quadratic_domain.vertex_in_range,
        "linear_fallback_coefs": linear_fallback_coefs,
        "linear_fallback_r2": linear_fallback_r2,
    }
    return calibration_params, float(r_squared)


def _range_tolerance(base: float, rel: float = 1e-4, abs_tol: float = 1e-9) -> float:
    return max(abs_tol, abs(float(base)) * rel)


def _response_bounds_from_standards(ys) -> tuple[float, float]:
    ys = np.asarray(ys, dtype=float)
    if ys.size == 0:
        return 0.0, 0.0
    return float(np.min(ys)), float(np.max(ys))


def assess_sample_quantification_range(y_value: float, conc: float, calibration_params: dict) -> dict:
    """
    判断样品响应/反算浓度是否落在标准品建立的验证范围内。
    超出时标记 Out_of_Range，并说明是否为 clip 到端点浓度。
    """
    ys = np.asarray(calibration_params.get("y_original", []), dtype=float)
    cmin = float(calibration_params.get("conc_min", 0.0))
    cmax = float(calibration_params.get("conc_max", 1.0))
    y_lo = float(calibration_params.get("y_min", np.min(ys) if ys.size else 0.0))
    y_hi = float(calibration_params.get("y_max", np.max(ys) if ys.size else 0.0))
    conc = float(conc)
    valid_solution = np.isfinite(conc) and conc >= 0.0

    resp_below = ys.size > 0 and y_value < y_lo - _range_tolerance(y_lo)
    resp_above = ys.size > 0 and y_value > y_hi + _range_tolerance(y_hi)
    conc_below = valid_solution and conc < cmin - _range_tolerance(cmin)
    conc_above = valid_solution and conc > cmax + _range_tolerance(cmax)

    clipped_low = resp_below and abs(conc - cmin) <= _range_tolerance(cmin, rel=0.02)
    clipped_high = resp_above and abs(conc - cmax) <= _range_tolerance(cmax, rel=0.02)

    reasons: list[str] = []
    if not valid_solution:
        reasons.append("no_valid_solution")
    if resp_below:
        reasons.append("response_below_standards")
    if resp_above:
        reasons.append("response_above_standards")
    if conc_below:
        reasons.append("concentration_below_range")
    if conc_above:
        reasons.append("concentration_above_range")
    if clipped_low:
        reasons.append("clipped_to_min")
    if clipped_high:
        reasons.append("clipped_to_max")

    in_range = not reasons
    return {
        "Out_of_Range": not in_range,
        "Range_Status": "in_range" if in_range else ";".join(reasons),
        "Response_In_Range": not (resp_below or resp_above),
        "Concentration_In_Range": valid_solution and not (conc_below or conc_above),
        "Calibration_Y_Min": y_lo,
        "Calibration_Y_Max": y_hi,
        "Calibration_Conc_Min": cmin,
        "Calibration_Conc_Max": cmax,
    }


def _reference_guided_estimate(y_value: float, calibration_params: dict) -> tuple[float, str]:
    """Estimate amount from same-plate standards without assuming global monotonicity."""
    xs = np.asarray(calibration_params.get("X_original", []), dtype=float)
    ys = np.asarray(calibration_params.get("y_original", []), dtype=float)
    valid = np.isfinite(xs) & np.isfinite(ys) & (xs >= 0)
    xs, ys = xs[valid], ys[valid]
    if xs.size == 0:
        return 0.0, "zero_default_no_valid_standards"

    order = np.argsort(ys)
    ys_sorted, xs_sorted = ys[order], xs[order]
    unique_y, inverse = np.unique(ys_sorted, return_inverse=True)
    unique_x = np.array([np.mean(xs_sorted[inverse == i]) for i in range(unique_y.size)])
    if unique_y.size >= 2:
        estimate = float(np.interp(y_value, unique_y, unique_x))
        return max(0.0, estimate), "same_plate_response_interpolation"

    return max(0.0, float(np.mean(xs))), "same_plate_standard_mean"


def select_quadratic_root(y_value: float, calibration_params: dict) -> dict:
    """Select a quadratic inverse using the closest same-plate local estimate."""
    a = float(calibration_params["a"])
    b = float(calibration_params["b"])
    c = float(calibration_params["c"])
    cmin = float(calibration_params.get("conc_min", 0.0))
    cmax = float(calibration_params.get("conc_max", 1.0))
    local_estimate, estimate_method = _reference_guided_estimate(y_value, calibration_params)
    details = {
        "roots": [], "in_range_roots": [], "local_estimate": local_estimate,
        "local_estimate_method": estimate_method, "selected": None, "reason": "",
    }

    if abs(a) < 1e-12:
        if abs(b) <= 1e-12:
            details["reason"] = "degenerate_quadratic"
            return details
        conc = float((y_value - c) / b)
        details["roots"] = [conc]
        if np.isfinite(conc) and conc >= 0 and cmin <= conc <= cmax:
            details["in_range_roots"] = [conc]
            details["selected"] = conc
            details["reason"] = "single_linear_equivalent_root"
        else:
            details["reason"] = "linear_equivalent_root_outside_working_range"
        return details

    discriminant = b * b - 4 * a * (c - y_value)
    if discriminant < 0:
        details["reason"] = "no_real_quadratic_root"
        return details

    sqrt_d = float(np.sqrt(discriminant))
    roots = [float((-b + sqrt_d) / (2 * a)), float((-b - sqrt_d) / (2 * a))]
    details["roots"] = roots
    tolerance = _range_tolerance(max(abs(cmin), abs(cmax)))
    valid = [
        float(r) for r in roots
        if np.isfinite(r) and r >= 0 and cmin - tolerance <= r <= cmax + tolerance
    ]
    details["in_range_roots"] = valid
    if len(valid) == 1:
        details["selected"] = valid[0]
        details["reason"] = "single_root_in_working_range"
    elif len(valid) == 2:
        distances = [abs(root - local_estimate) for root in valid]
        if abs(distances[0] - distances[1]) <= _range_tolerance(local_estimate):
            details["reason"] = "equidistant_roots_unresolved"
        else:
            details["selected"] = valid[int(np.argmin(distances))]
            details["reason"] = "closest_to_same_plate_standard_estimate"
    else:
        details["reason"] = "no_root_in_working_range"
    return details


def solve_concentration_from_quadratic(y_value: float, calibration_params: dict) -> float:
    """Compatibility wrapper returning the selected quadratic root or NaN."""
    selected = select_quadratic_root(y_value, calibration_params)["selected"]
    return float(selected) if selected is not None else float("nan")


def solve_concentration_from_linear(y_value: float, calibration_params: dict) -> float:
    """Back-calculate concentration from y = bx + c."""
    slope = float(calibration_params["b"])
    intercept = float(calibration_params["c"])
    if abs(slope) < 1e-12:
        raise ValueError("Linear calibration cannot be inverted because its slope is zero")
    return float((y_value - intercept) / slope)


def calculate_sample_concentrations(sample_results, calibration_params):
    """Back-calculate samples by quadratic root, linear fit, then interpolation."""
    method_mode = str(calibration_params.get("quantification_method", "quadratic")).lower()

    cmin = float(calibration_params.get("conc_min", 0.0))
    cmax = float(calibration_params.get("conc_max", 1.0))

    for result in sample_results:
        y_value = _extract_y_value(result, calibration_params["y_axis_type"])
        root_details = None
        fallback_reason = ""
        if method_mode == "quadratic":
            root_details = select_quadratic_root(y_value, calibration_params)
            selected = root_details["selected"]
            if selected is not None:
                conc = float(selected)
                method = "quadratic_branch_selected" if len(root_details["in_range_roots"]) == 2 else "quadratic"
            else:
                fallback_reason = root_details["reason"]
                fallback_coefs = calibration_params.get("linear_fallback_coefs")
                conc = float("nan")
                if fallback_coefs is not None:
                    slope, intercept = float(fallback_coefs[1]), float(fallback_coefs[2])
                    if abs(slope) > 1e-12:
                        candidate = float((y_value - intercept) / slope)
                        if np.isfinite(candidate) and candidate >= 0:
                            conc, method = candidate, "linear_fallback"
                if not np.isfinite(conc):
                    conc, interpolation_reason = _reference_guided_estimate(y_value, calibration_params)
                    method = "interpolation_fallback"
                    fallback_reason = f"{fallback_reason};{interpolation_reason}".strip(";")
        elif method_mode == "linear":
            conc = solve_concentration_from_linear(y_value, calibration_params)
            if not np.isfinite(conc) or conc < 0:
                conc, fallback_reason = _reference_guided_estimate(y_value, calibration_params)
                method = "interpolation_fallback"
            else:
                method = "linear"
        else:
            raise ValueError(f"Unsupported quantification method: {method_mode}")
        range_info = assess_sample_quantification_range(y_value, conc, calibration_params)

        result["Calculated_Concentration"] = conc
        result["Calculated_Amount_Per_Band"] = conc
        result["Concentration_Method"] = method
        result["Applied_Method"] = method
        result["Fallback_Reason"] = fallback_reason
        if root_details is not None:
            roots = root_details["roots"]
            result["Quadratic_Root_1"] = roots[0] if len(roots) > 0 else None
            result["Quadratic_Root_2"] = roots[1] if len(roots) > 1 else None
            result["Local_Standard_Estimate"] = root_details["local_estimate"]
            result["Selected_Root"] = root_details["selected"]
            result["Root_Selection_Reason"] = root_details["reason"]
        result.update(range_info)
        result["Quantification_Status"] = "out_of_range_estimate" if range_info["Out_of_Range"] else method

        if range_info["Out_of_Range"]:
            LOGGER.warning(
                f"Sample spot {result.get('Spot_Index', '?')} out of range: "
                f"y={y_value:.4g} (standards {range_info['Calibration_Y_Min']:.4g}"
                f"–{range_info['Calibration_Y_Max']:.4g}), "
                f"conc={conc:.6g} (validated {cmin:.6g}-{cmax:.6g}), "
                f"status={range_info['Range_Status']}"
            )
    return sample_results


def plot_calibration_curve(standard_results, standard_concentrations, calibration_params, r_squared,
                           save_path, background_type="other"):
    """Plot measured standards and the selected calibration model."""
    plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica", "sans-serif"]
    plt.rcParams["axes.unicode_minus"] = False

    y_axis_type = calibration_params["y_axis_type"]
    y_label = calibration_params["y_label"]
    concentrations = np.asarray(standard_concentrations, dtype=float)
    y_values = np.asarray([_extract_y_value(r, y_axis_type) for r in standard_results], dtype=float)
    bg_name = "Blue background" if background_type == "blue" else "Other background"
    spearman = calibration_params.get("spearman", None)
    quant_mode = str(calibration_params.get("quantification_method", "quadratic")).lower()

    order = np.argsort(concentrations)
    x_sorted = concentrations[order]
    y_sorted = y_values[order]
    plt.figure(figsize=(12, 8))
    plt.scatter(x_sorted, y_sorted, color="blue", s=70, label="Standards (measured)", zorder=5)
    for x, y in zip(x_sorted, y_sorted):
        plt.annotate(f"{x:.5f}", (x, y), textcoords="offset points", xytext=(5, 5), ha="left", fontsize=8, alpha=0.7)

    x_min, x_max = float(x_sorted.min()), float(x_sorted.max())
    x_fit = np.linspace(max(0.0, x_min * 0.8), x_max * 1.2, 200)
    y_fit = np.polyval(calibration_params["coefs"], x_fit)
    fit_r2 = float(calibration_params.get("r_squared", r_squared))
    model_label = "Quadratic" if quant_mode == "quadratic" else "Linear"
    plt.plot(x_fit, y_fit, "r-", linewidth=2.5, label=f"{model_label} calibration (R2={fit_r2:.3f})")

    plt.xlabel("Concentration", fontsize=12)
    plt.ylabel(y_label, fontsize=12)
    title = f"TLC calibration curve ({bg_name})\nConcentration vs {y_label}"
    if spearman is not None:
        title += f"\nMeasured Spearman={float(spearman):.3f} (red = {quant_mode} quantification)"
    plt.title(title, fontsize=13)
    plt.legend(fontsize=9, loc="best")
    plt.grid(True, alpha=0.3)

    a, b, c = calibration_params["a"], calibration_params["b"], calibration_params["c"]
    if quant_mode == "quadratic":
        equation = f"y={a:.4g}x^2+{b:.4g}x+{c:.4g}"
    else:
        equation = f"y={b:.4g}x+{c:.4g}"
    info = f"{model_label}: {equation} (R2={fit_r2:.4f})\nMethod: {quant_mode} regression back-calculation"
    plt.text(
        0.02, 0.98, info, transform=plt.gca().transAxes, fontsize=10,
        verticalalignment="top",
        bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.85),
    )

    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close()


def calculate_local_background(gray_im, box, margin=10):
    """计算斑点周围的局部背景（单斑点回退用；优先改用泳道共用背景）。"""
    height, width = gray_im.shape

    x1 = max(0, box[0] - margin)
    y1 = max(0, box[1] - margin)
    x2 = min(width, box[2] + margin)
    y2 = min(height, box[3] + margin)

    background_mask = np.ones((y2 - y1, x2 - x1), dtype=bool)
    spot_x1 = box[0] - x1
    spot_y1 = box[1] - y1
    spot_x2 = box[2] - x1
    spot_y2 = box[3] - y1

    if (0 <= spot_x1 < (x2 - x1) and 0 <= spot_y1 < (y2 - y1) and
            0 <= spot_x2 <= (x2 - x1) and 0 <= spot_y2 <= (y2 - y1)):
        background_mask[spot_y1:spot_y2, spot_x1:spot_x2] = False

    background_region = gray_im[y1:y2, x1:x2]
    if np.any(background_mask):
        # 用中位数，降低邻近斑点亮/暗边缘污染
        local_bg = float(np.median(background_region[background_mask]))
    else:
        local_bg = float(np.median(gray_im))

    return local_bg


def estimate_lane_background(gray_im, spot_boxes, y_pad: int = 45, x_pad: int = 10) -> float:
    """
    估计整条展开泳道的共用背景。
    在斑点所在水平带内，排除所有斑点 x 范围后取中位数，避免“局部环状背景”
    被左右邻近斑点污染，从而破坏标准品单调性。
    """
    if gray_im is None or gray_im.size == 0:
        return 1.0
    h, w = gray_im.shape[:2]
    if not spot_boxes:
        return float(np.median(gray_im))

    y_centers = [((int(b[1]) + int(b[3])) // 2) for b in spot_boxes]
    y_med = int(np.median(y_centers))
    y1 = max(0, y_med - y_pad)
    y2 = min(h, y_med + y_pad)
    band = gray_im[y1:y2, :].astype(np.float32)
    keep = np.ones(band.shape, dtype=bool)
    for box in spot_boxes:
        xx1 = max(0, int(box[0]) - x_pad)
        xx2 = min(w, int(box[2]) + x_pad)
        if xx2 > xx1:
            keep[:, xx1:xx2] = False

    vals = band[keep]
    if vals.size < 80:
        # 回退：图像四边
        m = max(6, min(h, w) // 20)
        border = np.concatenate([
            gray_im[:m, :].ravel(),
            gray_im[-m:, :].ravel(),
            gray_im[:, :m].ravel(),
            gray_im[:, -m:].ravel(),
        ]).astype(np.float32)
        return float(np.median(border)) if border.size else float(np.median(gray_im))
    return float(np.median(vals))


def detect_signal_polarity(spot_means, background: float) -> str:
    """荧光：斑点比背景亮；吸收：斑点比背景暗。"""
    if not spot_means:
        return "fluorescence"
    brighter = sum(1 for m in spot_means if float(m) >= float(background))
    return "fluorescence" if brighter >= 0.5 * len(spot_means) else "absorption"


def compute_net_integral(gray_roi, background: float, mask_roi=None, polarity: str = "auto"):
    """
    极性感知净信号积分：
    - fluorescence: sum(max(I - bg, 0))
    - absorption:   sum(max(bg - I, 0))
    有 mask 时只统计斑点像素，避免固定矩形里大量底板干扰单调性。
    """
    if gray_roi is None or gray_roi.size == 0:
        return 0.0, 0.0, polarity if polarity != "auto" else "fluorescence"

    roi = gray_roi.astype(np.float32)
    if mask_roi is not None:
        mask_bin = mask_roi > 0.5
        pixels = roi[mask_bin] if np.any(mask_bin) else roi.ravel()
    else:
        pixels = roi.ravel()

    if pixels.size == 0:
        return 0.0, 0.0, polarity if polarity != "auto" else "fluorescence"

    mean_fg = float(pixels.mean())
    if polarity == "auto":
        polarity = "fluorescence" if mean_fg >= float(background) else "absorption"

    bg = float(background)
    if polarity == "fluorescence":
        net = np.maximum(pixels - bg, 0.0)
    else:
        net = np.maximum(bg - pixels, 0.0)

    return float(net.sum()), float(net.mean()), polarity


def compute_masked_od(gray_roi, background: float, mask_roi=None) -> tuple[float, float]:
    """仅在 mask（或整块 ROI）上累计光密度，避免矩形底板虚高。"""
    if gray_roi is None or gray_roi.size == 0 or background <= 0:
        return 0.0, 0.0
    od_map = calculate_optical_density(gray_roi, background)
    if mask_roi is not None:
        mask_bin = mask_roi > 0.5
        if np.any(mask_bin):
            vals = od_map[mask_bin]
        else:
            vals = od_map.ravel()
    else:
        vals = od_map.ravel()
    if vals.size == 0:
        return 0.0, 0.0
    return float(vals.sum()), float(vals.mean())


def extract_lane_chromatogram(
    gray_im: np.ndarray,
    y_center: int,
    half_height: int,
    polarity: str,
    lane_bg: float,
) -> tuple[np.ndarray, np.ndarray]:
    """
    沿展开方向提取一维色谱图：每个 x 取竖直窄带平均灰度，再转成净信号。
    荧光: max(I-bg,0)；吸收: max(bg-I,0)。
    """
    h, w = gray_im.shape[:2]
    y1 = max(0, int(y_center) - int(half_height))
    y2 = min(h, int(y_center) + int(half_height) + 1)
    if y2 <= y1 or w <= 0:
        return np.arange(0), np.zeros(0, dtype=np.float32)

    band = gray_im[y1:y2, :].astype(np.float32)
    col_mean = band.mean(axis=0)
    bg = float(lane_bg)
    if polarity == "fluorescence":
        net = np.maximum(col_mean - bg, 0.0)
    else:
        net = np.maximum(bg - col_mean, 0.0)
    return np.arange(w, dtype=np.float32), net.astype(np.float32)


def integrate_1d_peak_areas(
    profile: np.ndarray,
    x_centers: list[int],
    default_half_width: int = 65,
) -> list[float]:
    """
    在相邻斑点中点处分窗，窗内扣线性基线后梯形积分，得到一维峰面积。
    """
    if profile is None or len(profile) == 0 or not x_centers:
        return [0.0] * len(x_centers)

    w = len(profile)
    xs = [int(np.clip(x, 0, w - 1)) for x in x_centers]
    n = len(xs)
    areas: list[float] = []

    for i, xc in enumerate(xs):
        if n == 1:
            left = max(0, xc - default_half_width)
            right = min(w - 1, xc + default_half_width)
        else:
            if i == 0:
                left = max(0, xc - default_half_width)
                right = (xc + xs[i + 1]) // 2
            elif i == n - 1:
                left = (xs[i - 1] + xc) // 2
                right = min(w - 1, xc + default_half_width)
            else:
                left = (xs[i - 1] + xc) // 2
                right = (xc + xs[i + 1]) // 2
            # 防止窗过窄
            left = min(left, xc)
            right = max(right, xc)

        if right <= left:
            areas.append(0.0)
            continue

        seg = profile[left: right + 1].astype(np.float64)
        # 线性基线：连接窗口两端
        baseline = np.linspace(float(seg[0]), float(seg[-1]), seg.size)
        net = np.maximum(seg - baseline, 0.0)
        try:
            areas.append(float(np.trapezoid(net)))
        except AttributeError:
            areas.append(float(np.trapz(net)))

    return areas


def attach_1d_peak_areas(
    results: list[dict],
    gray_im: np.ndarray,
    band_half_height: int,
    polarity: str,
    lane_bg: float,
    default_half_width: int = 65,
    profile_save_path=None,
) -> list[dict]:
    """给每个斑点写入 Peak_Area_1D，可选保存色谱图。"""
    if not results or gray_im is None or gray_im.size == 0:
        return results

    y_center = int(np.median([r["Y_Position"] for r in results]))
    x_centers = [int(r["X_Position"]) for r in results]
    xs, profile = extract_lane_chromatogram(gray_im, y_center, band_half_height, polarity, lane_bg)
    areas = integrate_1d_peak_areas(profile, x_centers, default_half_width=default_half_width)

    for r, a in zip(results, areas):
        r["Peak_Area_1D"] = round(float(a), 2)

    print(f"1D peak areas: {areas}")

    if profile_save_path is not None and xs.size > 0:
        try:
            plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica", "sans-serif"]
            plt.rcParams["axes.unicode_minus"] = False
            plt.figure(figsize=(12, 4))
            plt.plot(xs, profile, color="steelblue", linewidth=1.2, label="1D net-signal profile")
            for r, a in zip(results, areas):
                plt.axvline(r["X_Position"], color="orange", alpha=0.35, linewidth=1)
                plt.text(r["X_Position"], max(profile) * 0.95 if profile.max() > 0 else 1.0,
                         f"#{r['Spot_Index']}\n{a:.0f}", ha="center", va="top", fontsize=7)
            plt.xlabel("Development direction X (pixel)")
            plt.ylabel("Net signal")
            plt.title(f"1D peak profile ({polarity}, bg={lane_bg:.1f})")
            plt.legend(loc="upper right", fontsize=8)
            plt.tight_layout()
            plt.savefig(profile_save_path, dpi=200, bbox_inches="tight")
            plt.close()
        except Exception as e:
            print(f"Failed to save 1D profile plot: {e}")

    return results


def calculate_peak_area(gray_im, mask, box, baseline_method='local', baseline_value=None):
    """
    计算斑点的峰面积积分（替代AUC）

    参数:
    - gray_im: 灰度图像
    - mask: 斑点的二值掩码
    - box: 边界框坐标
    - baseline_method: 基线计算方法 ('local', 'global', 'min', 'fixed')
    - baseline_value: 固定基线值

    返回:
    - peak_area: 峰面积积分
    - baseline: 使用的基线值
    - intensity_data: 强度数据
    """
    x1, y1, x2, y2 = box

    # 提取斑点区域
    spot_region = gray_im[y1:y2, x1:x2]
    spot_mask = mask[y1:y2, x1:x2]

    if spot_region.size == 0:
        return 0, 0, None

    # 确定基线
    if baseline_method == 'local':
        # 使用斑点周围的局部背景
        local_bg = calculate_local_background(gray_im, box)
        baseline = local_bg
    elif baseline_method == 'global':
        baseline = gray_im.mean()
    elif baseline_method == 'min':
        baseline = np.min(spot_region[spot_mask]) if np.any(spot_mask) else np.min(spot_region)
    elif baseline_method == 'fixed' and baseline_value is not None:
        baseline = baseline_value
    else:
        baseline = np.mean(spot_region)  # 默认使用斑点区域平均值

    # 计算峰面积积分 - 使用二维积分方法
    if np.any(spot_mask):
        # 仅对掩码区域计算
        spot_intensities = spot_region[spot_mask]
    else:
        # 如果没有有效掩码，使用整个区域
        spot_intensities = spot_region.flatten()

    # 减去基线并确保非负
    above_baseline = np.maximum(spot_intensities - baseline, 0)

    # 计算峰面积积分（所有像素的强度之和）
    peak_area = np.sum(above_baseline)

    return peak_area, baseline, spot_intensities


def process_spots_sorted(det, masks, gray_im, color_im, fixed_width, fixed_height, y_tolerance=60):
    """增强的斑点处理函数，包含详细的光密度计算和调试信息"""
    boxes = det[:, :4].cpu().numpy().astype(int)
    masks = masks.cpu().numpy()

    # 1. 找到基准线
    y_centers = [(box[1] + box[3]) // 2 for box in boxes]
    y_line = np.median(y_centers)

    # 2. 收集同一行的斑点
    spots_in_line = []
    for idx, (box, mask) in enumerate(zip(boxes, masks)):
        y_center = (box[1] + box[3]) // 2
        if abs(y_center - y_line) <= y_tolerance:
            spots_in_line.append({
                'index': idx,
                'box': box,
                'mask': mask,
                'x_center': (box[0] + box[2]) // 2,
                'y_center': y_center
            })

    # 3. 按x坐标排序（左→右 = 标准品浓度顺序）
    spots_in_line.sort(key=lambda x: x['x_center'])

    results = []
    global_mean_bg = float(np.median(gray_im)) if gray_im.size else 1.0
    height, width = gray_im.shape

    # 先准备固定 ROI，再估共用泳道背景与信号极性
    prepared = []
    for spot in spots_in_line:
        center_x = spot['x_center']
        center_y = spot['y_center']
        start_x = max(0, center_x - fixed_width // 2)
        start_y = max(0, center_y - fixed_height // 2)
        end_x = min(width, start_x + fixed_width)
        end_y = min(height, start_y + fixed_height)
        actual_width = end_x - start_x
        actual_height = end_y - start_y
        if actual_width < fixed_width * 0.8 or actual_height < fixed_height * 0.8:
            continue
        fixed_roi = gray_im[start_y:end_y, start_x:end_x]
        if fixed_roi.size == 0:
            continue
        full_mask = spot["mask"]
        if full_mask.ndim > 2:
            full_mask = np.squeeze(full_mask)
        mask_roi = full_mask[start_y:end_y, start_x:end_x]
        roi_box = [start_x, start_y, end_x, end_y]
        prepared.append({
            "spot": spot,
            "roi_box": roi_box,
            "fixed_roi": fixed_roi,
            "color_roi": color_im[start_y:end_y, start_x:end_x],
            "mask_roi": mask_roi,
            "center_x": center_x,
            "center_y": center_y,
            "actual_width": actual_width,
            "actual_height": actual_height,
            "mean_fg": float(fixed_roi.mean()),
        })

    lane_boxes = [p["roi_box"] for p in prepared]
    lane_bg = estimate_lane_background(gray_im, lane_boxes)
    polarity = detect_signal_polarity([p["mean_fg"] for p in prepared], lane_bg)

    print(f"Global background (median): {global_mean_bg:.2f}")
    print(f"Lane shared background: {lane_bg:.2f}")
    print(f"Signal polarity: {polarity} ({'fluorescence = spot brighter' if polarity == 'fluorescence' else 'absorption = spot darker'})")
    if global_mean_bg < 10:
        print("Warning: low global background may affect OD calculation")

    for spot_idx, item in enumerate(prepared):
        spot = item["spot"]
        box = spot["box"]
        mask = spot["mask"]
        fixed_roi = item["fixed_roi"]
        color_roi = item["color_roi"]
        mask_roi = item["mask_roi"]
        center_x = item["center_x"]
        center_y = item["center_y"]
        actual_width = item["actual_width"]
        actual_height = item["actual_height"]
        mean_fg = item["mean_fg"]
        sum_gray = int(fixed_roi.sum())

        local_bg = calculate_local_background(gray_im, item["roi_box"], margin=15)
        # 定量统一用泳道共用背景，避免邻近斑点污染导致非单调
        bg_use = lane_bg

        sum_gray_corrected, mean_gray_corrected, _ = compute_net_integral(
            fixed_roi, bg_use, mask_roi, polarity=polarity
        )
        net_signal = sum_gray_corrected

        sum_od, mean_od = compute_masked_od(fixed_roi, bg_use, mask_roi)
        sum_od_global, mean_od_global = compute_masked_od(fixed_roi, global_mean_bg, mask_roi)
        sum_od_local, mean_od_local = compute_masked_od(fixed_roi, local_bg, mask_roi)
        od_method = "lane_shared+mask"

        roi_clipped = (actual_width < fixed_width) or (actual_height < fixed_height)
        if roi_clipped:
            print(
                f"Warning: spot {spot_idx} near image edge; ROI clipped to {actual_width}x{actual_height}; "
                f"integral may be biased (raw gray sum={sum_gray}, net signal={net_signal:.0f})"
            )

        print(f"\n--- Spot {spot_idx} OD / net signal ---")
        print(f"ROI shape: {fixed_roi.shape}, mean intensity: {mean_fg:.2f}")
        print(f"Local bg: {local_bg:.2f}, lane bg: {bg_use:.2f}, global: {global_mean_bg:.2f}")
        print(f"Net signal: {net_signal:.2f}, total OD in mask: {sum_od:.4f}")

        peak_area, baseline_peak, intensity_data = calculate_peak_area(gray_im, mask, box, 'local')

        if color_roi.size > 0:
            avg_B = np.mean(color_roi[:, :, 0])
            avg_G = np.mean(color_roi[:, :, 1])
            avg_R = np.mean(color_roi[:, :, 2])
            hsv_roi = cv2.cvtColor(color_roi, cv2.COLOR_BGR2HSV)
            avg_H = np.mean(hsv_roi[:, :, 0])
            avg_S = np.mean(hsv_roi[:, :, 1])
            avg_V = np.mean(hsv_roi[:, :, 2])
            lab_roi = cv2.cvtColor(color_roi, cv2.COLOR_BGR2Lab)
            avg_L = np.mean(lab_roi[:, :, 0])
            avg_A = np.mean(lab_roi[:, :, 1])
            avg_B_lab = np.mean(lab_roi[:, :, 2])
            C_map = np.sqrt(lab_roi[:, :, 1].astype(float) ** 2 + lab_roi[:, :, 2].astype(float) ** 2)
            avg_C = np.mean(C_map)
        else:
            avg_R = avg_G = avg_B = 0
            avg_H = avg_S = avg_V = 0
            avg_L = avg_A = avg_B_lab = avg_C = 0

        ratio_local = mean_fg / local_bg if local_bg > 0 else 0
        ratio_global = mean_fg / global_mean_bg if global_mean_bg > 0 else 0
        ratio_lane = mean_fg / bg_use if bg_use > 0 else 0

        result = {
            "Image": "",
            "Spot_Index": spot_idx,
            "Original_Index": spot['index'],
            "X_Position": center_x,
            "Y_Position": center_y,
            "Width": actual_width,
            "Height": actual_height,
            "Area": actual_width * actual_height,
            "Mean_Gray": round(float(mean_fg), 2),
            "Sum_Gray": sum_gray,
            "Sum_Gray_Corrected": round(float(sum_gray_corrected), 2),
            "Mean_Gray_Corrected": round(float(mean_gray_corrected), 2),
            "Net_Signal": round(float(net_signal), 2),
            "Signal_Polarity": polarity,
            "Lane_Background": round(float(bg_use), 2),
            "ROI_Clipped": roi_clipped,
            "Mean_OD": round(float(mean_od), 4),
            "Sum_OD": round(float(sum_od), 4),
            "Mean_OD_Global": round(float(mean_od_global), 4),
            "Sum_OD_Global": round(float(sum_od_global), 4),
            "Mean_OD_Local": round(float(mean_od_local), 4),
            "Sum_OD_Local": round(float(sum_od_local), 4),
            "OD_Method": od_method,
            "IOD": round(float(sum_od_global), 4),
            "Peak_Area": round(float(peak_area), 4),
            "Baseline_Peak": round(float(bg_use), 2),
            "Global_Background": round(float(global_mean_bg), 2),
            "Local_Background": round(float(local_bg), 2),
            "Gray_Ratio_Global": round(float(ratio_global), 4),
            "Gray_Ratio_Local": round(float(ratio_local), 4),
            "Gray_Ratio_Lane": round(float(ratio_lane), 4),
            "Center_Point": f"{center_x},{center_y}",
            "R": round(float(avg_R), 2),
            "G": round(float(avg_G), 2),
            "B": round(float(avg_B), 2),
            "H": round(float(avg_H), 2),
            "S": round(float(avg_S), 2),
            "V": round(float(avg_V), 2),
            "L": round(float(avg_L), 2),
            "A": round(float(avg_A), 2),
            "B_lab": round(float(avg_B_lab), 2),
            "C": round(float(avg_C), 2),
            "Spot_Type": "",
            "Known_Concentration": None,
            "Calculated_Concentration": None,
            "Calculated_Amount_Per_Band": None,
            "Out_of_Range": False,
            "Range_Status": "",
            "Response_In_Range": True,
            "Concentration_In_Range": True,
            "Spot_Source": "auto",
            "Manual_Rect": "",
        }
        results.append(result)
        print(
            f"Spot {spot_idx} final - raw gray sum: {sum_gray}, "
            f"net signal: {net_signal:.0f}, total OD in mask: {sum_od:.4f}"
        )

    return results


@smart_inference_mode()
def run(
        weights=ROOT / "weights/best.pt",  # trained TLC-RAPID weights
        source=ROOT / "user_input/images",  # input image directory
        data=ROOT / "weights/boCenColor.yaml",  # dataset.yaml path
        imgsz=(640, 640),  # inference size (height, width)
        conf_thres=0.15,  # confidence threshold (lower = more sensitive to detect weak spots)
        iou_thres=0.3,  # NMS IOU threshold
        max_det=1000,  # maximum detections per image
        device="",  # cuda device, i.e. 0 or 0,1,2,3 or cpu
        view_img=False,  # show results
        save_txt=False,  # save results to *.txt
        save_conf=False,  # save confidences in --save-txt labels
        save_crop=False,  # save cropped prediction boxes
        nosave=False,  # do not save images/videos
        classes=None,  # filter by class: --class 0, or --class 0 2 3
        agnostic_nms=False,  # class-agnostic NMS
        augment=False,  # augmented inference
        visualize=False,  # visualize features
        update=False,  # update all models
        project=ROOT / "runs/predict-seg",  # save results to project/name
        name="exp",  # save results to project/name
        exist_ok=False,  # existing project/name ok, do not increment
        line_thickness=3,  # bounding box thickness (pixels)
        hide_labels=False,  # hide labels
        hide_conf=False,  # hide confidences
        half=False,  # use FP16 half-precision inference
        dnn=False,  # use OpenCV DNN for ONNX inference
        vid_stride=1,  # video frame-rate stride
        retina_masks=False,
        fixed_width=130,  # 矩形宽度
        fixed_height=35,  # 矩形高度
        standard_num=5,  # 新增：标准品数量
        standard_concentrations="0.125,0.2,0.25,0.5,1",  # 默认标准品浓度
        y_axis_type='sum_od',  # 修改：默认使用总光密度值
        mask_interference=True,  # 新增：是否遮盖水平线外干扰斑点后二次推理（默认启用）
        mask_color='background',  # 新增：遮盖颜色 background/white/black
        mask_pad=6,  # 新增：遮盖框膨胀像素
        mask_save=True,  # 新增：保存遮盖后的中间图（默认启用）
        mask_x_margin=30,  # 新增：自动保护右侧条带的x边界外扩像素
        y_tolerance=60,  # 新增：水平带容忍范围（像素），用于判断斑点是否在同一水平线
        manual_mark=True,  # 新增：启用手动矩形补标
        manual_save_json=True,  # 新增：保存手动框选json
        concentrations_by_image=None,  # 新增：按图片名读取浓度（由 run_analysis.py 传入）
        quantification_method="quadratic",  # quadratic=default; linear=alternative
        imaging_mode="auto",  # auto/366nm/visible/254nm，固定 IGI 或 IOD
):
    """Run YOLOv5 segmentation inference on diverse sources including images, videos, directories, and streams."""
    try:
        from utils.load_user_config import minimum_standard_count, normalize_quantification_method, normalize_imaging_mode
        quantification_method = normalize_quantification_method(quantification_method)
        imaging_mode = normalize_imaging_mode(imaging_mode)
    except Exception:
        quantification_method = str(quantification_method or "quadratic").strip().lower()
        if quantification_method not in ("quadratic", "linear"):
            quantification_method = "quadratic"
        minimum_standard_count = lambda method: 4 if method == "quadratic" else 3
        imaging_mode = str(imaging_mode or "auto").strip().lower()

    source = str(source)
    save_img = not nosave and not source.endswith(".txt")  # save inference images
    is_file = Path(source).suffix[1:] in (IMG_FORMATS + VID_FORMATS)
    is_url = source.lower().startswith(("rtsp://", "rtmp://", "http://", "https://"))
    webcam = source.isnumeric() or source.endswith(".streams") or (is_url and not is_file)
    screenshot = source.lower().startswith("screen")
    if is_url and is_file:
        source = check_file(source)  # download

    # 解析标准品浓度 - 支持高精度小数
    if concentrations_by_image is None:
        try:
            from utils.load_user_config import load_concentrations
            concentrations_by_image = load_concentrations()
            LOGGER.info("Loaded concentrations from user_input/standard_concentrations.csv")
        except Exception as e:
            LOGGER.warning(f"Failed to load concentration table: {e}")
            concentrations_by_image = None

    try:
        standard_conc = [float(x.strip()) for x in standard_concentrations.split(",")]
    except (TypeError, ValueError) as e:
        raise ValueError(f"Failed to parse standard concentrations: {e}") from e

    required_standards = minimum_standard_count(quantification_method)
    if standard_num < required_standards or len(standard_conc) < required_standards:
        raise ValueError(
            f"At least {required_standards} distinct standard concentrations are required "
            f"for {quantification_method} quantification"
        )
    if len(standard_conc) != standard_num:
        raise ValueError(
            f"Concentration count ({len(standard_conc)}) does not match standard_num ({standard_num})"
        )
    if not all(np.isfinite(conc) for conc in standard_conc):
        raise ValueError("Standard concentrations must all be finite numbers")
    if any(conc < 0 for conc in standard_conc):
        raise ValueError("Standard concentrations must be non-negative")
    if len(set(standard_conc)) != len(standard_conc):
        raise ValueError("Standard concentrations must be distinct calibration levels")

    # 验证浓度精度
    for i, conc in enumerate(standard_conc):
        if abs(conc - round(conc, 10)) > 1e-10:  # 检查是否支持高精度
            LOGGER.info(f"Standard {i + 1}: concentration = {conc:.10f}")

    # Directories
    save_dir = increment_path(Path(project) / name, exist_ok=exist_ok)  # increment run
    (save_dir / "labels" if save_txt else save_dir).mkdir(parents=True, exist_ok=True)  # make dir
    # 保存本次运行的完整参数，方便复现/对比不同 exp 目录的差异
    try:
        yaml_save(save_dir / "opt.yaml", {k: (str(v) if isinstance(v, Path) else v) for k, v in locals().items()
                                          if k in {
                                              "weights", "source", "data", "imgsz", "conf_thres", "iou_thres", "max_det",
                                              "device", "view_img", "save_txt", "save_conf", "save_crop", "nosave",
                                              "classes", "agnostic_nms", "augment", "visualize", "update", "project",
                                              "name", "exist_ok", "line_thickness", "hide_labels", "hide_conf", "half",
                                              "dnn", "vid_stride", "retina_masks", "fixed_width", "fixed_height",
                                              "standard_num", "standard_concentrations", "y_axis_type",
                                              "quantification_method", "imaging_mode",
                                              "mask_interference", "mask_color", "mask_pad", "mask_save", "mask_x_margin",
                                              "y_tolerance",
                                              "manual_mark", "manual_save_json",
                                          }})
    except Exception as e:
        LOGGER.warning(f"Failed to save opt.yaml: {e}")

    # Load model
    device = select_device(device)
    model = DetectMultiBackend(weights, device=device, dnn=dnn, data=data, fp16=half)
    stride, names, pt = model.stride, model.names, model.pt
    imgsz = check_img_size(imgsz, s=stride)  # check image size

    # Dataloader
    bs = 1  # batch_size
    if webcam:
        view_img = check_imshow(warn=True)
        dataset = LoadStreams(source, img_size=imgsz, stride=stride, auto=pt, vid_stride=vid_stride)
        bs = len(dataset)
    elif screenshot:
        dataset = LoadScreenshots(source, img_size=imgsz, stride=stride, auto=pt)
    else:
        dataset = LoadImages(source, img_size=imgsz, stride=stride, auto=pt, vid_stride=vid_stride)
    vid_path, vid_writer = [None] * bs, [None] * bs

    # Run inference
    model.warmup(imgsz=(1 if pt else bs, 3, *imgsz))  # warmup
    seen, windows, dt = 0, [], (Profile(device=device), Profile(device=device), Profile(device=device))

    all_results = []
    image_statuses = []

    for path, im, im0s, vid_cap, s in dataset:
        im0 = im0s.copy()
        gray_im = cv2.cvtColor(im0, cv2.COLOR_BGR2GRAY)

        # 添加图像统计信息分析
        analyze_image_statistics(gray_im, im0)

        with dt[0]:
            im = torch.from_numpy(im).to(model.device)
            im = im.half() if model.fp16 else im.float()  # uint8 to fp16/32
            im /= 255  # 0 - 255 to 0.0 - 1.0
            if len(im.shape) == 3:
                im = im[None]  # expand for batch dim

        # Inference
        with dt[1]:
            visualize = increment_path(save_dir / Path(path).stem, mkdir=True) if visualize else False
            pred, proto = model(im, augment=augment, visualize=visualize)[:2]

        # NMS
        with dt[2]:
            agnostic_nms = True
            pred = non_max_suppression(pred, conf_thres, iou_thres, classes, agnostic_nms, max_det=max_det, nm=32)

        # Process predictions
        for i, det in enumerate(pred):  # per image
            seen += 1
            if webcam:  # batch_size >= 1
                p, im0, frame = path[i], im0s[i].copy(), dataset.count
                s += f"{i}: "
            else:
                p, im0, frame = path, im0s.copy(), getattr(dataset, "frame", 0)

            p = Path(p)  # to Path
            image_status = {
                "Image": p.name,
                "Detection_Status": "not_run",
                "Quantification_Status": "failed",
                "Spot_Count": 0,
                "Error_Message": "",
            }
            save_path = str(save_dir / p.name)  # im.jpg
            txt_path = str(save_dir / "labels" / p.stem) + ("" if dataset.mode == "image" else f"_{frame}")  # im.txt
            s += "%gx%g " % im.shape[2:]  # print string
            imc = im0.copy() if save_crop else im0  # for save_crop
            annotator = Annotator(im0, line_width=line_thickness, example=str(names))

            if len(det):
                image_status["Detection_Status"] = "detected"
                if retina_masks:
                    # scale bbox first the crop masks
                    det[:, :4] = scale_boxes(im.shape[2:], det[:, :4], im0.shape).round()  # rescale boxes to im0 size
                    masks = process_mask_native(proto[i], det[:, 6:], det[:, :4], im0.shape[:2])  # HWC
                else:
                    masks = process_mask(proto[i], det[:, 6:], det[:, :4], im.shape[2:], upsample=True)  # HWC
                    det[:, :4] = scale_boxes(im.shape[2:], det[:, :4], im0.shape).round()  # rescale boxes to im0 size

                # Segments
                if save_txt:
                    segments = [
                        scale_segments(im0.shape if retina_masks else im.shape[2:], x, im0.shape, normalize=True)
                        for x in reversed(masks2segments(masks))
                    ]

                # Print results
                for c in det[:, 5].unique():
                    n = (det[:, 5] == c).sum()  # detections per class
                    s += f"{n} {names[int(c)]}{'s' * (n > 1)}, "  # add to string

                # Mask plotting
                annotator.masks(
                    masks,
                    colors=[colors(x, True) for x in det[:, 5]],
                    im_gpu=torch.as_tensor(im0, dtype=torch.float16).to(device).permute(2, 0, 1).flip(0).contiguous()
                           / 255
                    if retina_masks
                    else im[i],
                )

                # ========= 干扰斑点遮盖 + 二次推理（以第一个点为基准）=========
                boxes_np = det[:, :4].cpu().numpy().astype(int)
                y_ref = choose_reference_y_from_boxes_xyxy(boxes_np, y_tolerance=y_tolerance)

                det_use, masks_use, im0_use, gray_use = det, masks, im0, gray_im

                # 如果检测到的点太少（少于3个），不启用遮盖，避免误遮盖
                if mask_interference and y_ref is not None and len(boxes_np) >= 3:
                    # 调试信息：显示遮盖范围
                    y_centers_all = (boxes_np[:, 1] + boxes_np[:, 3]) / 2.0
                    in_band_count = np.sum(np.abs(y_centers_all - float(y_ref)) <= float(y_tolerance))
                    LOGGER.info(f"Mask debug: y_ref={y_ref}, y_tolerance={y_tolerance}, "
                              f"boxes in band={in_band_count}/{len(boxes_np)}, "
                              f"band=[{y_ref - y_tolerance}, {y_ref + y_tolerance}]")
                    # 自动计算 x_limit：用"同一水平线内"的斑点最右边界，保护其右侧区域不被遮盖
                    x_limit = None
                    try:
                        y_centers = (boxes_np[:, 1] + boxes_np[:, 3]) / 2.0
                        in_band = np.abs(y_centers - float(y_ref)) <= float(y_tolerance)
                        if np.any(in_band):
                            x_limit = int(np.max(boxes_np[in_band, 2]) + int(mask_x_margin))
                    except Exception:
                        x_limit = None

                    im0_masked = mask_outside_band(
                        im0_bgr=im0,
                        boxes_xyxy=boxes_np,
                        y_ref=y_ref,
                        y_tolerance=y_tolerance,
                        pad=mask_pad,
                        color_mode=mask_color,
                        x_limit=x_limit,
                    )

                    if mask_save:
                        masked_path = str(save_dir / f"{p.stem}_masked.jpg")
                        cv2.imwrite(masked_path, im0_masked)

                    # 二次推理：在遮盖后的图上重新检测
                    im2_np, _ = preprocess_im0_for_model(im0_masked, imgsz, stride=stride, auto=pt)
                    im2 = torch.from_numpy(im2_np).to(model.device)
                    im2 = im2.half() if model.fp16 else im2.float()
                    im2 /= 255
                    if len(im2.shape) == 3:
                        im2 = im2[None]

                    pred2, proto2 = model(im2, augment=augment, visualize=False)[:2]
                    # 第二遍推理适当放宽置信度阈值，尽量找出弱斑点
                    conf_thres_second = min(conf_thres * 0.5, 0.2)
                    # 与第一遍保持一致：第5个参数为 agnostic_nms(位置参数)
                    pred2 = non_max_suppression(
                        pred2, conf_thres_second, iou_thres, classes, True, max_det=max_det, nm=32
                    )

                    # 只处理当前图片这一张（batch=1）
                    det2 = pred2[0]
                    if det2 is not None and len(det2):
                        det2[:, :4] = scale_boxes(im2.shape[2:], det2[:, :4], im0_masked.shape).round()
                        if retina_masks:
                            masks2 = process_mask_native(proto2[0], det2[:, 6:], det2[:, :4], im0_masked.shape[:2])
                        else:
                            masks2 = process_mask(proto2[0], det2[:, 6:], det2[:, :4], im2.shape[2:], upsample=True)

                        det_use, masks_use = det2, masks2
                        im0_use = im0_masked
                        gray_use = cv2.cvtColor(im0_use, cv2.COLOR_BGR2GRAY)

                # 使用增强的斑点处理函数
                spots_results = process_spots_sorted(det_use, masks_use, gray_use, im0_use, fixed_width, fixed_height, y_tolerance)

                # 手动多框补标：在自动识别结果基础上补漏检点
                # 部分笔记本 OpenCV 弹窗会闪退，失败则自动跳过
                manual_rects = []
                if manual_mark:
                    try:
                        manual_base = im0.copy()
                        for r in spots_results:
                            cx, cy = int(r["X_Position"]), int(r["Y_Position"])
                            x1, y1, x2, y2 = rect_from_center(cx, cy, fixed_width, fixed_height, im0.shape[1], im0.shape[0])
                            cv2.rectangle(manual_base, (x1, y1), (x2, y2), (0, 255, 0), 2)
                            cv2.putText(manual_base, "AUTO", (x1, max(15, y1 - 5)),
                                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

                        LOGGER.info("Manual mark: Left-click = ADD, Right-click = DELETE, S = save, Esc = skip")
                        print(f"\nOpening Manual Mark window for: {p.name}")
                        print("Click the image window to focus it, then follow the on-screen instructions.")
                        print("Left-click = ADD  |  Right-click = DELETE  |  S = next  |  Esc = skip")
                        manual_rects = select_manual_rectangles(
                            manual_base,
                            window_name=f"Manual Mark - {p.name}",
                            fixed_width=fixed_width,
                            fixed_height=fixed_height,
                        )
                        if manual_rects:
                            manual_results = process_manual_rectangles(
                                gray_im=gray_im,
                                color_im=im0,
                                manual_rects=manual_rects,
                                start_spot_idx=len(spots_results),
                                fixed_width=fixed_width,
                                fixed_height=fixed_height,
                            )
                            spots_results.extend(manual_results)

                        if manual_save_json:
                            manual_json = {
                                "image": p.name,
                                "timestamp": datetime.now().isoformat(timespec="seconds"),
                                "manual_rects_xyxy": manual_rects,
                                "count": len(manual_rects),
                            }
                            with open(save_dir / f"{p.stem}_manual_rects.json", "w", encoding="utf-8") as f:
                                json.dump(manual_json, f, ensure_ascii=False, indent=2)
                    except Exception as e:
                        LOGGER.error(f"Manual mark window failed; skipped: {e}")
                        print(f"[Warning] Manual mark unavailable ({e}); continuing with auto detection.")
                        try:
                            cv2.destroyAllWindows()
                        except Exception:
                            pass

                spots_results = sorted(spots_results, key=lambda x: x["X_Position"])
                for new_idx, item in enumerate(spots_results):
                    item["Spot_Index"] = new_idx
                image_status["Spot_Count"] = len(spots_results)

                # 一维峰面积（色谱峰思路）：在最终斑点列表上统一计算
                if spots_results:
                    polarity = spots_results[0].get("Signal_Polarity") or detect_signal_polarity(
                        [r["Mean_Gray"] for r in spots_results],
                        float(spots_results[0].get("Lane_Background", np.median(gray_use))),
                    )
                    lane_bg = float(spots_results[0].get("Lane_Background", np.median(gray_use)))
                    half_h = max(8, int(fixed_height // 2))
                    attach_1d_peak_areas(
                        spots_results,
                        gray_use,
                        band_half_height=half_h,
                        polarity=polarity,
                        lane_bg=lane_bg,
                        default_half_width=max(20, int(fixed_width // 2)),
                        profile_save_path=None,
                    )

                # 为每个结果添加图像名称
                for result in spots_results:
                    result["Image"] = p.name
                    all_results.append(result)

                # ========== 标准曲线计算和浓度定量 ==========
                # 支持每张图片使用不同浓度（从 user_input/标准品浓度.csv 读取）
                image_conc = standard_conc
                image_standard_num = standard_num
                if concentrations_by_image:
                    from utils.load_user_config import get_concentrations_for_image, has_explicit_concentrations
                    image_conc = get_concentrations_for_image(concentrations_by_image, p.name)
                    image_standard_num = len(image_conc)
                    LOGGER.info(f"Image [{p.name}] standard concentrations: {image_conc}")
                    if not has_explicit_concentrations(concentrations_by_image, p.name):
                        LOGGER.warning(
                            f"Image [{p.name}] not in concentration table; using (default) row. "
                            f"Expected filename in table: {p.name}"
                        )

                if len(spots_results) > image_standard_num:
                    # 分离标准品和样品
                    standard_results = spots_results[:image_standard_num]
                    sample_results = spots_results[image_standard_num:]

                    # 为标准品添加已知浓度
                    for i, result in enumerate(standard_results):
                        if i < len(image_conc):
                            result["Spot_Type"] = "standard"
                            result["Known_Concentration"] = image_conc[i]

                    # 为样品标记类型
                    for result in sample_results:
                        result["Spot_Type"] = "sample"

                    # 论文优先 IGI/IOD；366nm 时 IGI 退化则备选 peak_1d
                    background_type = resolve_imaging_profile(imaging_mode, im0)
                    conc_for_fit = image_conc[:len(standard_results)]
                    image_y_axis_type, image_y_label, axis_source, spearman_abs = select_paper_response_axis(
                        standard_results, conc_for_fit, background_type
                    )

                    LOGGER.info(
                        f"imaging_mode={imaging_mode}, background={background_type} "
                        f"({'366nm' if background_type == 'blue' else 'visible/254nm'})"
                    )
                    LOGGER.info(
                        f"Response axis: {image_y_label} ({image_y_axis_type}, source={axis_source}), "
                        f"|Spearman|={spearman_abs:.3f}"
                    )
                    print(
                        f"imaging_mode={imaging_mode} -> background={background_type} -> "
                        f"axis={image_y_label} [{axis_source}] (|Spearman|={spearman_abs:.3f})"
                    )

                    for result in spots_results:
                        result["Background_Type"] = background_type
                        result["Calibration_Y_Axis"] = image_y_axis_type
                        result["Response_Axis_Source"] = axis_source
                        result["Imaging_Mode"] = imaging_mode
                        result["Quantification_Status"] = "pending"
                        result["Error_Message"] = ""

                    try:
                        calibration_params, r_squared = fit_calibration_model(
                            standard_results,
                            conc_for_fit,
                            y_axis_type=image_y_axis_type,
                            y_label=image_y_label,
                            quantification_method=quantification_method,
                        )
                        calibration_params["background_type"] = background_type
                        plot_conc = calibration_params.get("X_original", conc_for_fit)

                        sample_results = calculate_sample_concentrations(sample_results, calibration_params)

                        for result in spots_results:
                            result["Calibration_R2"] = float(calibration_params.get("r_squared", r_squared))
                            result["Quantification_Method"] = calibration_params.get(
                                "quantification_method", quantification_method
                            )
                            result["Method_Selection"] = calibration_params.get(
                                "method_selection", quantification_method
                            )
                            result["Requested_Method"] = calibration_params.get(
                                "requested_method", quantification_method
                            )
                            result["Calibration_Quality"] = calibration_params.get(
                                "calibration_quality", ""
                            )
                            result["Calibration_Y_Min"] = float(calibration_params.get("y_min", 0.0))
                            result["Calibration_Y_Max"] = float(calibration_params.get("y_max", 0.0))
                            result["Calibration_Conc_Min"] = float(calibration_params.get("conc_min", 0.0))
                            result["Calibration_Conc_Max"] = float(calibration_params.get("conc_max", 0.0))
                            if result.get("Spot_Type") == "standard":
                                result["Out_of_Range"] = False
                                result["Range_Status"] = "standard_reference"
                                result["Response_In_Range"] = True
                                result["Concentration_In_Range"] = True

                        calibration_plot_path = save_dir / f"{p.stem}_calibration_curve.png"
                        plot_calibration_curve(
                            standard_results,
                            plot_conc,
                            calibration_params,
                            r_squared,
                            calibration_plot_path,
                            background_type=background_type,
                        )

                        LOGGER.info(f"Calibration complete: R2 = {r_squared:.6f}")
                        a, b, c = calibration_params["a"], calibration_params["b"], calibration_params["c"]
                        if calibration_params["quantification_method"] == "quadratic":
                            equation = f"{a:.6f}*conc^2 + {b:.6f}*conc + {c:.6f}"
                        else:
                            equation = f"{b:.6f}*conc + {c:.6f}"
                        LOGGER.info(f"Calibration: {image_y_label} = {equation}")
                        LOGGER.info(
                            f"Background: {background_type}, Y-axis: {image_y_label}, "
                            f"quantification={calibration_params.get('quantification_method')}, "
                            f"order_reversed={calibration_params.get('order_reversed')}"
                        )

                        polarity = standard_results[0].get("Signal_Polarity", "")
                        lane_bg = standard_results[0].get("Lane_Background", "")
                        print(
                            f"\n=== Quantification (polarity={polarity}, lane_bg={lane_bg}, axis={image_y_label}) ==="
                        )
                        print("Standards:")
                        for result in standard_results:
                            y_value = _extract_y_value(result, image_y_axis_type)
                            print(
                                f"  Spot {result['Spot_Index']}: conc={result['Known_Concentration']:.10f}, "
                                f"{image_y_label}={y_value:.4f}"
                            )

                        print("Samples:")
                        for result in sample_results:
                            y_value = _extract_y_value(result, image_y_axis_type)
                            oOR = result.get("Out_of_Range", False)
                            flag = " [out of range]" if oOR else ""
                            status = result.get("Range_Status", "")
                            print(
                                f"  Spot {result['Spot_Index']}: calculated amount={result['Calculated_Amount_Per_Band']:.10f}, "
                                f"{image_y_label}={y_value:.4f}, method={result.get('Concentration_Method')}"
                                f"{flag} ({status})"
                            )

                        image_status["Quantification_Status"] = "success"
                        for result in spots_results:
                            if result.get("Spot_Type") == "standard":
                                result["Quantification_Status"] = "standard_reference"

                    except Exception as e:
                        error_message = f"{type(e).__name__}: {e}"
                        image_status["Quantification_Status"] = "failed"
                        image_status["Error_Message"] = error_message
                        for result in spots_results:
                            result["Quantification_Status"] = "failed"
                            result["Error_Message"] = error_message
                        LOGGER.error(f"Calibration failed for [{p.name}]: {error_message}")

                else:
                    error_message = (
                        f"Found {len(spots_results)} spot(s), but quantification requires "
                        f"at least {image_standard_num} standards plus 1 sample"
                    )
                    image_status["Quantification_Status"] = "failed"
                    image_status["Error_Message"] = error_message
                    for result in spots_results:
                        result["Quantification_Status"] = "failed"
                        result["Error_Message"] = error_message
                    LOGGER.error(f"Quantification failed for [{p.name}]: {error_message}")

                # 可视化：在图像上标注斑点序号和类型
                for result in spots_results:
                    center_x = result["X_Position"]
                    center_y = result["Y_Position"]
                    spot_index = result["Spot_Index"]
                    spot_type = result.get("Spot_Type", "unknown")
                    spot_source = result.get("Spot_Source", "auto")

                    # 根据斑点类型选择颜色
                    if spot_type == "standard":
                        color = (0, 255, 0)  # 绿色-标准品
                        label = f"S{spot_index}"
                    elif spot_type == "sample":
                        color = (255, 0, 0)  # 红色-样品
                        label = f"Sample{spot_index}"
                    else:
                        color = (0, 0, 255)  # 蓝色-未知
                        label = f"{spot_index}"

                    if spot_source == "manual":
                        color = (0, 255, 255)  # 黄色-手动补标
                        label = f"M{spot_index}"

                    # 在斑点中心标注序号和类型
                    cv2.putText(im0, label,
                                (center_x - 15, center_y - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

                    # 自动与手动补标均使用相同固定框大小
                    start_x = center_x - fixed_width // 2
                    start_y = center_y - fixed_height // 2
                    end_x = start_x + fixed_width
                    end_y = start_y + fixed_height

                    cv2.rectangle(im0,
                                  (start_x, start_y),
                                  (end_x, end_y),
                                  color, 2)

                # Write results
                for j, (*xyxy, conf, cls) in enumerate(reversed(det[:, :6])):
                    if save_txt:  # Write to file
                        seg = segments[j].reshape(-1)  # (n,2) to (n*2)
                        line = (cls, *seg, conf) if save_conf else (cls, *seg)  # label format
                        with open(f"{txt_path}.txt", "a") as f:
                            f.write(("%g " * len(line)).rstrip() % line + "\n")

                    if save_img or save_crop or view_img:  # Add bbox to image
                        c = int(cls)  # integer class
                        label = None if hide_labels else (names[c] if hide_conf else f"{names[c]} {conf:.2f}")
                        # annotator.box_label(xyxy, label, color=colors(c, True))
                        # annotator.draw.polygon(segments[j], outline=colors(c, True), width=3)
                    if save_crop:
                        save_one_box(xyxy, imc, file=save_dir / "crops" / names[c] / f"{p.stem}.jpg", BGR=True)

            else:
                error_message = "No spots detected; manual marking was not available for an empty detection result"
                image_status["Detection_Status"] = "no_detections"
                image_status["Quantification_Status"] = "failed"
                image_status["Error_Message"] = error_message
                LOGGER.error(f"Analysis failed for [{p.name}]: {error_message}")

            image_statuses.append(image_status)

            # Stream results
            im0 = annotator.result()
            if view_img:
                if platform.system() == "Linux" and p not in windows:
                    windows.append(p)
                    cv2.namedWindow(str(p), cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO)  # allow window resize (Linux)
                    cv2.resizeWindow(str(p), im0.shape[1], im0.shape[0])
                cv2.imshow(str(p), im0)
                if cv2.waitKey(1) == ord("q"):  # 1 millisecond
                    exit()

            # Save results (image with detections)
            if save_img:
                if dataset.mode == "image":
                    cv2.imwrite(save_path, im0)
                else:  # 'video' or 'stream'
                    if vid_path[i] != save_path:  # new video
                        vid_path[i] = save_path
                        if isinstance(vid_writer[i], cv2.VideoWriter):
                            vid_writer[i].release()  # release previous video writer
                        if vid_cap:  # video
                            fps = vid_cap.get(cv2.CAP_PROP_FPS)
                            w = int(vid_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                            h = int(vid_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                        else:  # stream
                            fps, w, h = 30, im0.shape[1], im0.shape[0]
                        save_path = str(Path(save_path).with_suffix(".mp4"))  # force *.mp4 suffix on results videos
                        vid_writer[i] = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
                    vid_writer[i].write(im0)

        # Print time (inference-only)
        LOGGER.info(f"{s}{'' if len(det) else '(no detections), '}{dt[1].dt * 1E3:.1f}ms")

    # Print results
    t = tuple(x.t / seen * 1e3 for x in dt)  # speeds per image
    LOGGER.info(f"Speed: %.1fms pre-process, %.1fms inference, %.1fms NMS per image at shape {(1, 3, *imgsz)}" % t)
    if save_txt or save_img:
        s = f"\n{len(list(save_dir.glob('labels/*.txt')))} labels saved to {save_dir / 'labels'}" if save_txt else ""
        LOGGER.info(f"Results saved to {colorstr('bold', save_dir)}{s}")

    excel_path = save_dir / "quantitative_analysis_all_images.xlsx"
    df = pd.DataFrame(all_results)
    status_df = pd.DataFrame(image_statuses)

    successful_images = sum(
        status.get("Quantification_Status") == "success" for status in image_statuses
    )
    failed_images = len(image_statuses) - successful_images
    if failed_images == 0 and successful_images > 0:
        exit_code = 0
    elif successful_images > 0:
        exit_code = 2
    else:
        exit_code = 1

    weight_value = weights[0] if isinstance(weights, (list, tuple)) and weights else weights
    metadata_values = build_provenance(root=ROOT, weights=weight_value, data_config=data)
    metadata_values.update(
        {
            "Analysis_Timestamp": datetime.now().astimezone().isoformat(timespec="seconds"),
            "Input_Source_Name": Path(source).name,
            "Input_Images": ", ".join(status.get("Image", "") for status in image_statuses),
            "Total_Images": len(image_statuses),
            "Successful_Images": successful_images,
            "Failed_Images": failed_images,
            "Exit_Code": exit_code,
            "Quantification_Method": quantification_method,
            "Imaging_Mode": imaging_mode,
            "Standard_Count": standard_num,
            "Default_Standard_Concentrations": standard_concentrations,
            "Per_Image_Standard_Concentrations": json.dumps(
                concentrations_by_image or {}, ensure_ascii=False, sort_keys=True
            ),
            "Confidence_Threshold": conf_thres,
            "NMS_IoU_Threshold": iou_thres,
            "Image_Size": json.dumps(list(imgsz) if isinstance(imgsz, (list, tuple)) else imgsz),
            "ROI_Width": fixed_width,
            "ROI_Height": fixed_height,
            "Y_Tolerance": y_tolerance,
            "Manual_Marking_Enabled": manual_mark,
        }
    )
    metadata_df = pd.DataFrame(
        [{"Field": key, "Value": str(value)} for key, value in metadata_values.items()]
    )

    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        metadata_df.to_excel(writer, sheet_name="Metadata", index=False)
        if not df.empty:
            # 按图像名称和斑点索引排序
            df = df.sort_values(['Image', 'Spot_Index'])

            # 设置pandas显示选项以确保高精度
            pd.set_option('display.float_format', '{:.10f}'.format)

            # 对于浓度列，确保高精度保存
            if 'Known_Concentration' in df.columns:
                df['Known_Concentration'] = df['Known_Concentration'].astype(float)
            if 'Calculated_Concentration' in df.columns:
                df['Calculated_Concentration'] = df['Calculated_Concentration'].astype(float)
            if 'Calculated_Amount_Per_Band' in df.columns:
                df['Calculated_Amount_Per_Band'] = df['Calculated_Amount_Per_Band'].astype(float)

            df.to_excel(writer, sheet_name="Results", index=False, float_format="%.10f")
        status_df.to_excel(writer, sheet_name="Image_Status", index=False)

        if not df.empty:
            try:
                from openpyxl.styles import Font

                ws = writer.sheets["Results"]
                bold = Font(bold=True)
                highlight_cols = {
                    "Known_Concentration",
                    "Calculated_Concentration",
                    "Calculated_Amount_Per_Band",
                }
                for col_idx, col_name in enumerate(df.columns, start=1):
                    if col_name not in highlight_cols:
                        continue
                    for row_idx in range(1, len(df) + 2):  # header + data
                        ws.cell(row=row_idx, column=col_idx).font = bold
            except Exception as e:
                LOGGER.warning(f"Could not bold concentration columns in Excel: {e}")
    LOGGER.info(f"Saved quantitative analysis status to {excel_path}")

    if not df.empty:
        # 打印每个图像的斑点顺序和灰度值用于验证
        print("\n=== Spot order and gray values ===")
        for image_name in df['Image'].unique():
            image_data = df[df['Image'] == image_name]
            print(f"Image: {image_name}")
            for _, row in image_data.iterrows():
                spot_type = row.get('Spot_Type', 'unknown')
                conc_info = ""
                if spot_type == "standard" and pd.notna(row.get('Known_Concentration')):
                    conc_info = f", known conc={row['Known_Concentration']:.10f}"
                elif spot_type == "sample" and pd.notna(row.get('Calculated_Concentration')):
                    conc_info = f", calculated amount={row['Calculated_Concentration']:.10f}"

                print(
                    f"  Spot {row['Spot_Index']}({spot_type}): mean gray={row['Mean_Gray']}, "
                    f"raw sum={row['Sum_Gray']}, corrected sum={row.get('Sum_Gray_Corrected', row['Sum_Gray'])}, "
                    f"total OD={row['Sum_OD']:.4f}{conc_info}")

    if update:
        strip_optimizer(weights[0])  # update model (to fix SourceChangeWarning)

    summary = {
        "exit_code": exit_code,
        "total_images": len(image_statuses),
        "successful_images": successful_images,
        "failed_images": failed_images,
        "excel_path": str(excel_path),
        "image_statuses": image_statuses,
    }
    LOGGER.info(
        f"Analysis summary: total={summary['total_images']}, successful={successful_images}, "
        f"failed={failed_images}, exit_code={exit_code}"
    )
    return summary


def parse_opt():
    """Parses command-line options for YOLOv5 inference including model paths, data sources, inference settings, and
    output preferences.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", nargs="+", type=str, default=str(ROOT / "weights/best.pt"),
                        help="model path(s)")
    parser.add_argument("--source", type=str, default=str(ROOT / "user_input/images"),
                        help="file/dir/URL/glob/screen/0(webcam)")
    parser.add_argument("--data", type=str, default=str(ROOT / "weights/boCenColor.yaml"),
                        help="(optional) dataset.yaml path")
    parser.add_argument("--imgsz", "--img", "--img-size", nargs="+", type=int, default=[640], help="inference size h,w")
    parser.add_argument("--conf-thres", type=float, default=0.15, help="confidence threshold (lower = more sensitive, default: 0.15)")
    parser.add_argument("--iou-thres", type=float, default=0.3, help="NMS IoU threshold")
    parser.add_argument("--max-det", type=int, default=1000, help="maximum detections per image")
    parser.add_argument("--device", default="", help="cuda device, i.e. 0 or 0,1,2,3 or cpu")
    parser.add_argument("--view-img", action="store_true", help="show results")
    parser.add_argument("--save-txt", action="store_true", help="save results to *.txt")
    parser.add_argument("--save-conf", action="store_true", help="save confidences in --save-txt labels")
    parser.add_argument("--save-crop", action="store_true", help="save cropped prediction boxes")
    parser.add_argument("--nosave", action="store_true", help="do not save images/videos")
    parser.add_argument("--classes", nargs="+", type=int, help="filter by class: --classes 0, or --classes 0 2 3")
    parser.add_argument("--agnostic-nms", action="store_true", help="class-agnostic NMS")
    parser.add_argument("--augment", action="store_true", help="augmented inference")
    parser.add_argument("--visualize", action="store_true", help="visualize features")
    parser.add_argument("--update", action="store_true", help="update all models")
    parser.add_argument("--project", default=ROOT / "runs/predict-seg", help="save results to project/name")
    parser.add_argument("--name", default="exp", help="save results to project/name")
    parser.add_argument("--exist-ok", action="store_true", help="existing project/name ok, do not increment")
    parser.add_argument("--line-thickness", default=3, type=int, help="bounding box thickness (pixels)")
    parser.add_argument("--hide-labels", default=False, action="store_true", help="hide labels")
    parser.add_argument("--hide-conf", default=False, action="store_true", help="hide confidences")
    parser.add_argument("--half", action="store_true", help="use FP16 half-precision inference")
    parser.add_argument("--dnn", action="store_true", help="use OpenCV DNN for ONNX inference")
    parser.add_argument("--vid-stride", type=int, default=1, help="video frame-rate stride")
    parser.add_argument("--retina-masks", action="store_true", help="whether to plot masks in native resolution")
    # 添加固定长宽参数
    parser.add_argument("--fixed-width", type=int, default=130,
                        help="width of the rectangular region (e.g., 30 pixels)")
    parser.add_argument("--fixed-height", type=int, default=35,
                        help="height of the rectangular region (e.g., 20 pixels)")
    # 新增标准曲线参数
    parser.add_argument("--standard-num", type=int, default=5,
                        help="number of standard spots (concentration known)")
    parser.add_argument("--standard-concentrations", type=str, default="0.125,0.2,0.25,0.5,1",
                        help="comma separated concentrations of standard spots (supports up to 10 decimal places)")
    # 新增纵坐标类型参数
    parser.add_argument("--y-axis-type", type=str, default="sum_od",  # 修改：默认使用总光密度值
                        choices=["sum_gray", "mean_gray", "sum_od", "mean_od"],
                        help="type of y-axis for calibration curve")
    parser.add_argument("--quantification-method", type=str, default="quadratic",
                        choices=["quadratic", "linear"],
                        help="concentration back-calculation: quadratic (default) or linear")
    # 新增：遮盖水平线外干扰斑点后二次推理（默认启用）
    parser.add_argument("--mask-interference", action="store_true", default=True,
                        help="mask spots outside the reference horizontal band and re-run inference (default: True)")
    parser.add_argument("--no-mask-interference", dest="mask_interference", action="store_false",
                        help="disable mask interference (opposite of --mask-interference)")
    parser.add_argument("--mask-color", type=str, default="background",
                        choices=["background", "white", "black"],
                        help="solid color used to cover interference spots")
    parser.add_argument("--mask-pad", type=int, default=6,
                        help="padding pixels added around interference boxes when masking")
    parser.add_argument("--mask-save", action="store_true", default=True,
                        help="save masked intermediate images for debugging (default: True)")
    parser.add_argument("--no-mask-save", dest="mask_save", action="store_false",
                        help="disable saving masked images (opposite of --mask-save)")
    parser.add_argument("--mask-x-margin", type=int, default=30,
                        help="auto x-limit margin to protect the right strip area from masking")
    parser.add_argument("--y-tolerance", type=int, default=60,
                        help="horizontal band tolerance (pixels) for judging if spots are on the same line (default: 60, larger = wider band)")
    parser.add_argument("--manual-mark", action="store_true", default=True,
                        help="enable manual rectangle marking for missed spots (default: True)")
    parser.add_argument("--no-manual-mark", dest="manual_mark", action="store_false",
                        help="disable manual rectangle marking")
    parser.add_argument("--manual-save-json", action="store_true", default=True,
                        help="save manual marked rectangles to json (default: True)")
    parser.add_argument("--no-manual-save-json", dest="manual_save_json", action="store_false",
                        help="disable saving manual marked rectangles json")
    opt = parser.parse_args()
    
    # 如果用户没有显式设置 mask_interference 和 mask_save，默认启用
    if "--mask-interference" not in sys.argv and "--no-mask-interference" not in sys.argv:
        opt.mask_interference = True
    if "--mask-save" not in sys.argv and "--no-mask-save" not in sys.argv:
        opt.mask_save = True
    if "--manual-mark" not in sys.argv and "--no-manual-mark" not in sys.argv:
        opt.manual_mark = True
    if "--manual-save-json" not in sys.argv and "--no-manual-save-json" not in sys.argv:
        opt.manual_save_json = True
    
    opt.imgsz *= 2 if len(opt.imgsz) == 1 else 1  # expand
    print_args(vars(opt))
    return opt


def main(opt):
    """Executes YOLOv5 model inference with given options, checking for requirements before launching."""
    check_requirements(ROOT / "requirements.txt", exclude=("tensorboard", "thop"))
    run(**vars(opt))


if __name__ == "__main__":
    opt = parse_opt()
    main(opt)
